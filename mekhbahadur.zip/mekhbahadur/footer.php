<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mekh_Bahadur
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		<div class="container">
			<div class="row">
				<?php do_action( 'activate_footer_widgets' ) ;?>
				<!--<div class="col-sm-12">
					<script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="top" style="display: block;"> <span class="fa fa-angle-up fa-2x" id="toTopHover" style="opacity: 1;"> </span></a>

				</div>-->
				<div class="col-sm-12 col-lg-12">
					<div class="site-info">
						<a class="toTop pull-right" href="#top" id="top"><span class="fa fa-angle-up fa-4x"></span></a>
						<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'mekhbahadur' ) ); ?>"><?php
							/* translators: %s: CMS name, i.e. WordPress. */
							printf( esc_html__( 'Proudly powered by %s', 'mekhbahadur' ), 'WordPress' );
						?></a>
						<span class="sep"> | </span>
						<?php
							/* translators: 1: Theme name, 2: Theme author. */
							printf( esc_html__( 'Theme: %1$s by %2$s.', 'mekhbahadur' ), 'mekhbahadur', '<a href="http://www.facebook.com/lovelymekh">Mekh Bahadur Layo</a>' );
						?>
					</div><!-- .site-info -->
				</div>
			</div>
		</div>
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
