/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


    $(document).ready(function() {
        $('body').scrollspy({target: ".site-footer", offset:50});
        $(".site-footer a#top[href='#top']").on('click', function(event) {
            event.preventDefault();
            var hash = this.hash;
            $('html, body').animate({
                scrollTop: $(hash).offset().top
                }, 1000, function() {
            });
        });
        $(document).scroll(function() {
        var y = $(this).scrollTop();
        if(y > 500) {
            $('.toTop').fadeIn(300);
        } else {
            $('.toTop').fadeOut(300);
        }
    } );
    });
        
    /* navigation sub-menu display */
    // Change 'hover' to 'click' if you want to
    $('#navbar li > .dropdown-menu').parent().hover(function() {
        var submenu = $(this).children('.dropdown-menu');
        if ( $(submenu).is(':hidden') ) {
            $(submenu).slideDown(200);
        } else {
        $(submenu).slideUp(200);
        }
    });

    