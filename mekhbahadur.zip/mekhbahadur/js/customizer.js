/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function( $ ) {

	// Site title and description.
	wp.customize( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );

	// Header text color.
	wp.customize( 'header_textcolor', function( value ) {
		value.bind( function( to ) {
			if ( 'blank' === to ) {
				$( '.site-title, .site-description' ).css( {
					'clip': 'rect(1px, 1px, 1px, 1px)',
					'position': 'absolute'
				} );
			} else {
				$( '.site-title, .site-description' ).css( {
					'clip': 'auto',
					'position': 'relative'
				} );
				$( '.site-title a, .site-description' ).css( {
					'color': to
				} );
			}
		} );
	} );

	// Header top padding
	wp.customize( 'padding_top_setting_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header' ).css( { 'padding-top': to + 'px' } );
		} );
	} );

	// Header bottom padding
	wp.customize( 'padding_bottom_setting_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header' ).css( { 'padding-bottom': to + 'px' } );
		} );
	} );

	// Header title line height
	wp.customize( 'title_lineheight_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header h1, .site-header h2, .site-header h3' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Header content line height
	wp.customize( 'content_lineheight_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header p' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Header background color
	wp.customize( 'bgcolor_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header' ).css( { 'background-color': to } );
		} );
	} );

	// Header content color
	wp.customize( 'color_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header p' ).css( { 'color': to } );
		} );
	} );

	// Content top padding
	wp.customize( 'padding_top_setting_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content' ).css( { 'padding-top': to + 'px' } );
		} );
	} );

	// Content bottom padding
	wp.customize( 'padding_bottom_setting_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content' ).css( { 'padding-bottom': to + 'px' } );
		} );
	} );

	// Content title line height
	wp.customize( 'title_lineheight_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content h1, .site-content h2, .site-content h3' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Content content line height
	wp.customize( 'content_lineheight_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content p' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Content background color
	wp.customize( 'bgcolor_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content' ).css( { 'background-color': to } );
		} );
	} );

	// Content content color
	wp.customize( 'color_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content p' ).css( { 'color': to } );
		} );
	} );

	// Footer top padding
	wp.customize( 'padding_top_setting_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer' ).css( { 'padding-top': to + 'px' } );
		} );
	} );

	// Footer bottom padding
	wp.customize( 'padding_bottom_setting_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer' ).css( { 'padding-bottom': to + 'px' } );
		} );
	} );

	// Footer title line height
	wp.customize( 'title_lineheight_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer h1, .site-footer h2, .site-footer h3' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Footer content line height
	wp.customize( 'content_lineheight_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer p' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Footer background color
	wp.customize( 'bgcolor_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer' ).css( { 'background-color': to } );
		} );
	} );

	// Footer content color
	wp.customize( 'color_3', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer p' ).css( { 'color': to } );
		} );
	} );

	// Service top padding
	wp.customize( 'padding_top_setting_4', function( value ) {
		value.bind( function( to ) {
			$( '.service' ).css( { 'padding-top': to + 'px' } );
		} );
	} );

	// Service bottom padding
	wp.customize( 'padding_bottom_setting_4', function( value ) {
		value.bind( function( to ) {
			$( '.service' ).css( { 'padding-bottom': to + 'px' } );
		} );
	} );

	// Service title line height
	wp.customize( 'title_lineheight_4', function( value ) {
		value.bind( function( to ) {
			$( '.service h1, .service h2, .service h3' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Header content line height
	wp.customize( 'content_lineheight_4', function( value ) {
		value.bind( function( to ) {
			$( '.service p' ).css( { 'line-height': to + 'em' } );
		} );
	} );

	// Service background color
	wp.customize( 'bgcolor_4', function( value ) {
		value.bind( function( to ) {
			$( '.service' ).css( { 'background-color': to } );
		} );
	} );

	// Content content color
	wp.customize( 'color_4', function( value ) {
		value.bind( function( to ) {
			$( '.service p' ).css( { 'color': to } );
		} );
	} );

	// Service section
	wp.customize( 'service_title_1', function( value ) {
		value.bind( function( to ) {
			$( '.service h1.title1, .service h2.title1, .service h3.title1' ).text( to );
		} );
	} );

	wp.customize( 'service_section_1', function( value ) {
		value.bind( function( to ) {
			$( '.service #section1' ).text( to );
		} );
	} );

	wp.customize( 'service_title_2', function( value ) {
		value.bind( function( to ) {
			$( '.service h1.title2, .service h2.title2, .service h3.title2' ).text( to );
		} );
	} );

	wp.customize( 'service_section_2', function( value ) {
		value.bind( function( to ) {
			$( '.service #section2' ).text( to );
		} );
	} );

	wp.customize( 'service_title_3', function( value ) {
		value.bind( function( to ) {
			$( '.service h1.title3, .service h2.title3, .service h3.title3' ).text( to );
		} );
	} );

	wp.customize( 'service_section_3', function( value ) {
		value.bind( function( to ) {
			$( '.service #section3' ).text( to );
		} );
	} )

	wp.customize( 'service_section_3', function( value ) {
		value.bind( function( to ) {
			$( '.service #section3' ).text( to );
		} );
	} );

	wp.customize( 'activate_social_setting', function( value ) {
		value.bind( function( to ) {
			$( '#social' ).text( to );
		} );
	} );

	// Header title font size 
	wp.customize( 'title_fontsize_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header h1, .site-header h2, .site-header h3' ).css( { 'font-size': to + 'px' } );
		} );
	} );
	// Header title font size 
	wp.customize( 'content_fontsize_1', function( value ) {
		value.bind( function( to ) {
			$( '.site-header p' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Content title font size 
	wp.customize( 'title_fontsize_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content .entry-title' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Content title font size 
	wp.customize( 'content_fontsize_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content p' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Service title font size 
	wp.customize( 'title_fontsize_3', function( value ) {
		value.bind( function( to ) {
			$( '.service h1, .service h2, .service h3' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Service title font size 
	wp.customize( 'content_fontsize_3', function( value ) {
		value.bind( function( to ) {
			$( '.service p' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Footer title font size 
	wp.customize( 'title_fontsize_4', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer h1, .site-footer h2, .site-footer h3' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Footer title font size 
	wp.customize( 'content_fontsize_4', function( value ) {
		value.bind( function( to ) {
			$( '.site-footer p' ).css( { 'font-size': to + 'px' } );
		} );
	} );

	// Service icon position
	wp.customize( 'service_icon_position_1', function( value ) {
		value.bind( function( to ) {
			$( '.service #icon-position-1' ).css( { 'margin-top': - to + 'px' } );
		} );
	} );

	// Service icon position
	wp.customize( 'service_icon_position_2', function( value ) {
		value.bind( function( to ) {
			$( '.service #icon-position-2' ).css( { 'margin-top': - to + 'px' } );
		} );
	} );

	// Service icon position
	wp.customize( 'service_icon_position_3', function( value ) {
		value.bind( function( to ) {
			$( '.service #icon-position-3' ).css( { 'margin-top': - to + 'px' } );
		} );
	} );

	/*// Icons
	wp.customize( 'title_icons_2', function( value ) {
		value.bind( function( to ) {
			$( '.site-content span' ).addClass( to );
		} );
	} );*/

} )( jQuery );
