<?php
/**
 * Mekh Bahadur Theme Customizer
 *
 * @package Mekh_Bahadur
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function mekhbahadur_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if( class_exists( 'WP_Customize_Control' ) ) {
		class WP_Customize_Padding_Control extends WP_Customize_Control {
			public $type = 'range';
			public $label = '';
			public function __construct( $manager, $id, $args = array() ) {
				parent::__construct( $manager, $id, $args );
				$defaults = array(
					'min' => 0,
					'max' => 150,
					'step' => 1
				);
				$args = wp_parse_args( $defaults, $args );
				$this->min = $args['min'];
				$this->max = $args['max'];
				$this->step = $args['step'];
 			}
 			public function render_content() { ?>
 			<h3 style="color:#ff9966;border-bottom: 2px dotted #252525;"><?php echo $this->label ;?></h3>
 			<p style="color:seagreen;"><?php echo $this->description; ?></p>
 			<label>
 				<input type="range" min="<?php echo $this->min ;?>" max="<?php echo $this->max ;?>" step="<?php echo $this->step ;?>" <?php $this->link() ;?> value="<?php echo $this->value() ;?>" oninput="jQuery(this).next('input').val(jQuery(this).val())">
 				<input type="button" onkeyup="jQuery(this).prev('input').val(jQuery(this).val())" value="<?php echo $this->value() ;?>" disabled="">
 			</label>
 			<?php 
 			}
		}
	}

	if( class_exists( 'WP_Customize_Control' ) ) {
		class WP_Customize_Height_Control extends WP_Customize_Control {
			public $type = 'range';
			public $label = '';
			public function __construct( $manager, $id, $args = array() ) {
				parent:: __construct( $manager, $id, $args );
				$defaults = array(
					'min' => 1.2,
					'max' => 3,
					'step' => 0.01
				);
				$args = wp_parse_args( $defaults, $args );
				$this->min = $args['min'];
				$this->max = $args['max'];
				$this->step = $args['step'];
			}
			public function render_content() { ?>
			<h3 style="color:#1c1c1c;"><?php echo $this->label;?></h3>
			<p><?php echo $this->description;?></p>
			<label>
				<input type="range" min="<?php echo $this->min ;?>" max="<?php echo $this->max ;?>" step="<?php echo $this->step;?>" <?php $this->link() ;?> value="<?php echo $this->value();?>" oninput="jQuery(this).next('input').val(jQuery(this).val())">
				<input type="button" value="<?php echo $this->value();?>" onkeyup="jQuery(this).prev('input').val(jQuery(this).val())" disabled="">
			</label>
			<?php
			}
		}
	}

	if( class_exists( 'WP_Customize_Control' ) ) {
		class WP_Customize_Fontsize_Control extends WP_Customize_Control {
			public $type = 'range';
			public $label = '';
			public function __construct( $manager, $id, $args = array() ) {
				parent::__construct( $manager, $id, $args );
				$defaults = array(
					'min' => 10,
					'max' => 72,
					'step' => 1
				);
				$args = wp_parse_args( $defaults, $args );
				$this->min = $args['min'];
				$this->max = $args['max'];
				$this->step = $args['step'];
			}
			public function render_content() { ?>
				<h3 style="border-bottom:1px dotted #ff9966;"><?php echo $this->label;?></h3>
				<p><?php echo $this->description ;?></p>
				<label>
					<input type="range" min="<?php echo $this->min;?>" max="<?php echo $this->max;?>" step="<?php echo $this->step ;?>" <?php $this->link() ;?> value="<?php echo $this->value();?>" oninput="jQuery(this).next('input').val(jQuery(this).val())">
					<input type="button" value="<?php echo $this->value();?>" onkeyup="jQuery(this).prev('input').val(jQuery(this).val())">
				</label>
				<?php
			}
		}
	}

	if( class_exists( 'WP_Customize_Control' ) ) {
		class WP_Customize_Iconposition_Control extends WP_Customize_Control {
			public $type = 'range';
			public $label = '';
			public function __construct( $manager, $id, $args = array() ) {
				parent:: __construct( $manager, $id, $args );
				$defaults = array(
					'min' => 1,
					'max' => 70,
					'step' => 1
				);
				$args = wp_parse_args( $defaults, $args );
				$this->min = $args['min'];
				$this->max = $args['max'];
				$this->step = $args['step'];
			}
			public function render_content() { ?>
				<h3><?php echo $this->label;?></h3>
				<p><?php echo $this->description;?></p>
				<label>
					<input type="range" min="<?php echo $this->min ;?>" max="<?php $this->max ;?>" step="<?php echo $this->step ;?>" <?php $this->link() ;?> value="<?php echo $this->value();?>" oninput="jQuery(this).next('input').val(jQuery(this).val())">
					<input type="button" value="<?php echo $this->value() ;?>" onkeyup="jQuery(this).prev('input').val(jQuery(this).val())" disabled="disabled">
				</label>
			<?php
			}
		}
	}

	// Remove header image section
	$wp_customize->remove_section( 'header_image' );

	// Remove Background image section
	$wp_customize->remove_section( 'background_image' );

	// Change the title_tagline
	$wp_customize->get_section( 'title_tagline' )->title = esc_html__('Site name, Description & Logo', 'mekhbahadur');
	// Assign title tagline to Theme Option section
	$wp_customize->get_section( 'title_tagline' )->panel = 'options';

	// Display title tagline in first order
	$wp_customize->get_section( 'title_tagline' )->priority = 1;
	//$wp_customize->remove_section( 'title_tagline' );

	// Change the color Title
	$wp_customize->get_section( 'colors' )->title = 'Theme Colors';

	// Add the panel "Theme Options"
	$wp_customize->add_panel( 'options',
		array(
			'title' => esc_html__( 'Theme Options', 'mekhbahadur' ),
			'priority' => 10,
			'capability' => 'edit_theme_options'
		) 
	);

	// Add the panel "Social"
	$wp_customize->add_panel( 'social', 
		array(
			'title' => esc_html__( 'Social', 'mekhbahadur' ),
			'priority' => 12,
			'capability' => 'edit_theme_options'
		) 
	);

	$wp_customize->add_section( 'logo', 
		array(
			'title' => esc_html__( 'Logo', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 8
		) 
	);

	$wp_customize->add_section( 'post_slider', 
		array(
			'title' => esc_html__( 'Post Slider', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 8
		) 
	);

	$wp_customize->add_section( 'padding_top', 
		array(
			'title' => esc_html__( 'Top Padding', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 10
		) 
	);

	$wp_customize->add_section( 'padding_bottom', 
		array(
			'title' => esc_html__( 'Bottom Padding', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 12
		) 
	);

	$wp_customize->add_section( 'lineheight', 
		array(
			'title' => esc_html__( 'Line height', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 14
		) 
	);

	$wp_customize->add_section( 'fontsize', 
		array(
			'title' => esc_html__( 'Typography settings', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 16
		) 
	);

	$wp_customize->add_section( 'service', 
		array(
			'title' => esc_html__( 'Service', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 18
		) 
	);

	$wp_customize->add_section( 'activate_social', 
		array(
			'title' => esc_html__( 'Activate social', 'mekhbahadur' ),
			'panel' => 'social',
			'priority' => 20
		) 
	);

	$wp_customize->add_section( 'social_setting', 
		array(
			'title' => esc_html__( 'Social settings', 'mekhbahadur' ),
			'panel' => 'social',
			'priority' => 22
		) 
	);

	$wp_customize->add_section( 'excerpt', 
		array(
			'title' => esc_html__( 'Excerpt', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 18
		) 
	);

	$wp_customize->add_section( 'footer', 
		array(
			'title' => esc_html__( 'Footer', 'mekhbahadur' ),
			'panel' => 'options',
			'priority' => 20,
			'description' => esc_html__( 'This section gives the option to display up-to four widgets on footer area.', 'mekhbahadur' )
		) 
	);

	$wp_customize->add_setting( 'logo_setting', 
		array(
			'default' => get_template_directory_uri() . '/images/logo.png',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_text_field',
			//'transport' => 'postMessage'
		) 
	);

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 
		'logo_setting', 
		array(
			'label' => esc_html__( 'Select logo', 'mekhbahadur' ),
			'section' => 'logo',
			'settings' => 'logo_setting',
			'mime_type' => 'image',
			'description' => esc_html__( 'This is the default image for logo. Choose your own logo.', 'mekhbahadur' )
		) ) 
	);

	$wp_customize->add_setting( 'activate_excerpt', 
		array(
			'default' => 'active',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_text_field',
			//'transpost' => 'postMessage'
		) 
	);

	$wp_customize->add_control( 'activate_excerpt', 
		array(
			'label' => esc_html__( 'Activate excerpt', 'mekhbahadur' ),
			'type' => 'checkbox',
			'section' => 'excerpt',
			'settings' => 'activate_excerpt',
			'description' => esc_html__( 'Check the box to activate social and uncheck to deactivate.', 'mekhbahadur' )
		) 
	);

	$wp_customize->add_setting( 'activate_post_slider', 
		array(
			'default' => '',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_text_field',
			//'transport' => 'postMessage'
		) 
	);

	$wp_customize->add_control( 'activate_post_slider', 
		array(
			'label' => esc_html__( 'Activate post slider', 'mekhbahadur' ),
			'section' => 'post_slider',
			'settings' => 'activate_post_slider',
			'type' => 'checkbox',
			'description' => esc_html__( 'Check the box to activate post slider', 'mekhbahadur' )
		) 
	);

	$wp_customize->add_setting( 'post_slider_setting', 
		array(
			'default' => '3000',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_input',
			'transport' => 'postMessage'
		) 
	);

	$wp_customize->add_control( 'post_slider_setting', 
		array(
			'label' => esc_html__( 'Post slider setting', 'mekhbahadur' ),
			'type' => 'number',
			'section' => 'post_slider',
			'settings' => 'post_slider_setting',
			'description' => esc_html__( 'This is the default post slider period in mili second. The default value is 3000 mili seconds. Your can update with your period.', 'mekhbahadur' )
		) 
	);

	for( $i = 1; $i <=4; $i++ ) {
		if( $i == 1 ) {
			$toppadding = 'Header top padding';
		} elseif( $i == 2 ) {
			$toppadding = 'Content top padding';
		} elseif( $i == 3 ) {
			$toppadding = 'Footer top padding';
		} elseif( $i == 4 ) {
			$toppadding = 'Service top padding';
		}

		$wp_customize->add_setting( 'padding_top_setting_' . $i, 
			array(
				'default' => '50',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Padding_Control( $wp_customize, 
			'padding_top_setting_' . $i, 
			array(
				'label' => esc_html__( '', 'mekhbahadur' ) . $toppadding . ' ' . $i,
				'type' => 'range',
				'section' => 'padding_top',
				'settings' => 'padding_top_setting_' . $i,
				'input_attrs' => array(
					'min' => 0,
					'max' => 150,
					'step' => 1
				),
				'description' => esc_html__( 'This is the top padding section. Set up the padding top value by sliding the button below.', 'mekhbahadur' )
			) ) 
		);
	}

	for( $i = 1; $i <=4; $i++ ) {
		if( $i == 1 ) {
			$bottompadding = 'Header bottom padding';
		} elseif( $i == 2 ) {
			$bottompadding = 'Content bottom padding';
		} elseif( $i == 3 ) {
			$bottompadding = 'Footer bottom padding';
		} elseif( $i == 4 ) {
			$bottompadding = 'Service bottom padding';
		}

		$wp_customize->add_setting( 'padding_bottom_setting_' . $i, 
			array(
				'default' => '50',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Padding_Control( $wp_customize, 
			'padding_bottom_setting_' . $i, 
			array(
				'label' => esc_html__( '', 'mekhbahadur' ) . $bottompadding . ' ' . $i,
				'type' => 'range',
				'section' => 'padding_bottom',
				'settings' => 'padding_bottom_setting_' . $i,
				'input_attrs' => array(
					'min' => 0,
					'max' => 150,
					'step' => 1
				),
				'description' => esc_html__( 'This is the bottom padding section. Set up the padding bottom value by sliding the button below.', 'mekhbahadur' )
			) ) 
		);
	}

	for( $i = 1; $i <=4; $i++ ) {
		if( $i == 1 ) {
			$lineheight = 'Header title line height';
			$lineheight1 = 'Header content line height';
		} elseif( $i == 2 ) {
			$lineheight = 'Content title line height';
			$lineheight1 = 'Content content line height';
		} elseif( $i == 3 ) {
			$lineheight = 'Footer title line height';
			$lineheight1 = 'Footer content line height';
		} elseif( $i == 4 ) {
			$lineheight = 'Service title line height';
			$lineheight1 = 'Service content line height';
		}

		$wp_customize->add_setting( 'title_lineheight_' . $i, 
			array(
				'default' => '1.4',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Height_Control( $wp_customize, 
			'title_lineheight_' . $i, 
			array(
				'label' => esc_html__( '', 'mekhbahadur' ) . $lineheight . ' ' . $i,
				'type' => 'range',
				'section' => 'lineheight',
				'settings' => 'title_lineheight_' . $i,
				'input_attrs' => array(
					'min' => 0.5,
					'max' => 3,
					'step' => 0.01
				),
				'description' => esc_html__( 'This is the line height option for title. Set up the title line height value by sliding the button below.', 'mekhbahadur' )
			) ) 
		);

		$wp_customize->add_setting( 'content_lineheight_' . $i, 
			array(
				'default' => '1.4',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Height_Control( $wp_customize, 
			'content_lineheight_' . $i, 
			array(
				'label' => esc_html__( '', 'mekhbahadur' ) . $lineheight1,
				'type' => 'range',
				'section' => 'lineheight',
				'settings' => 'content_lineheight_' . $i,
				'input_attrs' => array(
					'min' => 0.5,
					'max' => 3,
					'step' => 0.01
				),
				'description' => esc_html__( 'This is the line height option for content. Set up the content line height value by sliding the button below.', 'mekhbahadur' )
			) ) 
		);
	}

	for( $i = 1; $i <= 4; $i++ ) {
		if( $i == 1 ) {
			$title = 'Header title font size';
			$content = 'Header content font size';
			$magnify_icon = 'Magnify header title icon';
		} elseif( $i == 2 ) {
			$title = 'Content title font size';
			$content = 'Content content font size';
			$magnify_icon = 'Magnify content title icon';
		} elseif( $i == 3 ) {
			$title = 'Service title font size';
			$content = 'Service content font size';
			$magnify_icon = 'Magnify service title icon';
		} elseif( $i == 4 ) {
			$title = 'Footer title font size';
			$content = 'Footer content font size';
			$magnify_icon = 'Magnify footer title icon';
		}

		$wp_customize->add_setting( 'title_fontsize_' . $i, 
			array(
				'default' => '30',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Fontsize_Control( $wp_customize, 
			'title_fontsize_' . $i, 
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $i . ' ' . $title,
				'type' => 'range',
				'section' => 'fontsize',
				'settings' => 'title_fontsize_' . $i,
				'description' => esc_html__( 'This is the default title font size Update with your own size.', 'mekhbahadur' ),
				'input_attrs' => array(
					'min' => 30,
					'max' => 72,
					'step' => 1
				)
			) ) 
		);

		$wp_customize->add_setting( 'content_fontsize_' . $i, 
			array(
				'default' => '16',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Fontsize_Control( $wp_customize, 
			'content_fontsize_' . $i, 
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $content,
				'type' => 'range',
				'section' => 'fontsize',
				'settings' => 'content_fontsize_' . $i,
				'description' => esc_html__( 'This is the default content font size Update with your own size.', 'mekhbahadur' ),
				'input_attrs' => array(
					'min' => 16,
					'max' => 72,
					'step' => 1
				)
			) ) 
		);

		$wp_customize->add_setting( 'title_icons_' . $i,
			array(
				'default' => esc_html__( 'Select icon', 'mekhbahadur' ),
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( 'title_icons_' . $i,
			array(
				'label' => esc_html__( 'Header icon ', 'mekhbahadur' ) . $i,
				'section' => 'fontsize',
				'settings' => 'title_icons_' . $i,
				'type' => 'select',
				'choices' => mekhbahadur_icons(),
				'description' => esc_html__( 'Display the icon by choosing from the option below.', 'mekhbahadur' )
			)
		);

		$wp_customize->add_setting( 'title_icons_times_' . $i,
			array(
				'default' => esc_html__( 'Select icon', 'mekhbahadur' ),
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( 'title_icons_times_' . $i,
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $i . ' ' . $magnify_icon,
				'section' => 'fontsize',
				'settings' => 'title_icons_times_' . $i,
				'type' => 'radio',
				'choices' => array(
					'fa-1x' => esc_html__( 'Normal', 'mekhbahadur' ),
					'fa-2x' => esc_html__( 'fa-2x', 'mekhbahadur' ),
					'fa-3x' => esc_html__( 'fa-3x', 'mekhbahadur' ),
					'fa-4x' => esc_html__( 'fa-4x', 'mekhbahadur' ),
					'fa-5x' => esc_html__( 'fa-5x', 'mekhbahadur' ),
				),
				'description' => esc_html__( 'Magnify title icon size by choosing from the radion button.', 'mekhbahadur' )
			)
		);

		$wp_customize->add_setting( 'title_icon_position_' . $i,
			array(
				'default' => '35',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( new WP_Customize_Iconposition_Control( $wp_customize, 'title_icon_position_' . $i,
			array(
				'label' => esc_html__( 'Icon top position', 'mekhbahadur' ),
				'section' => 'fontsize',
				'settings' => 'title_icon_position_' . $i,
				'type' => 'range',
				'input_attrs' => array(
					'min' => 1,
					'max' => 70,
					'step' => 1
				),
				'description' => esc_html__( 'Margin top position for title icon.', 'mekhbahadur' )
			)
		) );
	}

	for( $i = 1; $i <= 4; $i++ ) {
		if( $i == 1 ) {
			$bgcolor = 'Header Background color';
			$color = 'Header content color';
		} elseif( $i == 2 ) {
			$bgcolor = 'Content Background color';
			$color = 'Content content color';
		} elseif( $i == 3 ) {
			$bgcolor = 'Footer Background color';
			$color = 'Footer content color';
		} elseif( $i == 4 ) {
			$bgcolor = 'Service Background color';
			$color = 'Service content color';
		}

		$wp_customize->add_setting( 'bgcolor_' . $i, 
			array(
				'default' => '',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 
			'bgcolor_' . $i, 
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $i . ' ' . $bgcolor,
				'section' => 'colors',
				'settings' => 'bgcolor_' . $i,
				'description' => esc_html__( 'Use different background colors by choosing from the box.', 'mekhbahadur' )
			) ) 
		);

		$wp_customize->add_setting( 'color_' . $i, 
			array(
				'default' => '',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_hex_color',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 
			'color_' . $i, 
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $color,
				'section' => 'colors',
				'settings' => 'color_' . $i,
				'description' => esc_html__( 'Use different colors by choosing from the box.', 'mekhbahadur' )
			) ) 
		);
	}

	$wp_customize->add_setting( 'activate_service', 
		array(
			'default' => 'active',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_text_field',
			//'transport' => 'postMessage'
		) 
	);

	$wp_customize->add_control( 'activate_service', 
		array(  
			'label' => esc_html__( 'Activate service', 'mekhbahadur' ),
			'type' => 'checkbox',
			'section' => 'service',
			'settings' => 'activate_service',
			'description' => esc_html__( 'Check the box to activate service and uncheck to deactivate.', 'mekhbahadur' )
		) 
	);

	for( $i = 1; $i <= 3; $i++ ) {

		$wp_customize->add_setting( 'service_title_' . $i, 
			array(
				'default' => esc_html__( 'Service title ', 'mekhbahadur' ) . $i,
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_text_field',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( 'service_title_' . $i, 
			array(
				'label' => esc_html__( 'Service title ', 'mekhbahadur' ),
				'type' => 'text',
				'section' => 'service', 
				'settings' => 'service_title_' . $i,
				'description' => esc_html__( 'This is the default title for the service section. You can update now.', 'mekhbahadur' )
			) 
		);

		$wp_customize->add_setting( 'service_section_' . $i, 
			array(
				'default' => esc_html__( 'This is the default service description. You can update the content of this section by going to the service section on the customization panel.', 'mekhbahadur' ),
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_text_field',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( 'service_section_' . $i, 
			array(
				'label' => esc_html__( 'Service section ', 'mekhbahadur' ) . $i,
				'type' => 'textarea',
				'section' => 'service', 
				'settings' => 'service_section_' . $i,
				'description' => esc_html__( 'This is the default description for the service section. You can update now.', 'mekhbahadur' )
			) 
		);

		$wp_customize->add_setting( 'service_icons_' . $i,
			array(
				'default' => esc_html__( 'Select icon', 'mekhbahadur' ),
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( 'service_icons_' . $i,
			array(
				'label' => esc_html__( 'Siervice title icon ', 'mekhbahadur' ) . $i,
				'section' => 'service',
				'settings' => 'service_icons_' . $i,
				'type' => 'select',
				'choices' => mekhbahadur_icons()
			)
		);

		$wp_customize->add_setting( 'service_icons_times_' . $i,
			array(
				'default' => esc_html__( 'Select icon', 'mekhbahadur' ),
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( 'service_icons_times_' . $i,
			array(
				'label' => esc_html__( 'Magnify service icon', 'mekhbahadur' ) . $i,
				'section' => 'service',
				'settings' => 'service_icons_times_' . $i,
				'type' => 'radio',
				'choices' => array(
					'fa-2x' => esc_html__( 'fa-2x', 'mekhbahadur' ),
					'fa-3x' => esc_html__( 'fa-3x', 'mekhbahadur' ),
					'fa-4x' => esc_html__( 'fa-4x', 'mekhbahadur' ),
					'fa-5x' => esc_html__( 'fa-5x', 'mekhbahadur' ),
				)
			)
		);

		$wp_customize->add_setting( 'service_icon_position_' . $i,
			array(
				'default' => '35',
				'type' => 'theme_mod',
				'sanitize_callback' => 'sanitize_input',
				'transport' => 'postMessage'
			)
		);

		$wp_customize->add_control( new WP_Customize_Iconposition_Control( $wp_customize, 'service_icon_position_' . $i,
			array(
				'label' => esc_html__( 'Top position', 'mekhbahadur' ),
				'section' => 'service',
				'settings' => 'service_icon_position_' . $i,
				'type' => 'range',
				'input_attrs' => array(
					'min' => 1,
					'max' => 70,
					'step' => 1
				)
			)
		) );
	}

	$wp_customize->add_setting( 'activate_social_setting', 
		array(
			'default' => 'checked',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_text_field',
			//'transport' => 'postMessage'
		) 
	);

	$wp_customize->add_control( 'activate_social_setting', 
		array(
			'label' => esc_html__( 'Activate social', 'mekhbahadur' ),
			'type' => 'checkbox',
			'section' => 'activate_social',
			'settings' => 'activate_social_setting',
			'description' => esc_html__( 'Check the box to activate social and uncheck to deactivate.', 'mekhbahadur' )
		) 
	);

	$socials = array(
		'facebook' => array(
			'id' => 'facebook',
			'title' => esc_html__( 'Facebook', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.facebook.com/', 'mekhbahadur' )
		),
		'twitter' => array(
			'id' => 'twitter',
			'title' => esc_html__( 'Twitter', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.twitter.com/', 'mekhbahadur' )
		),
		'gplus' => array(
			'id' => 'google_plus',
			'title' => esc_html__( 'Google plus', 'mekhbahadur' ),
			'default' => esc_html__( 'https://plus.google.com/', 'mekhbahadur' )
		),
		'linkedin' => array(
			'id' => 'linkedin',
			'title' => esc_html__( 'Linkedin', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.linkedin.com/', 'mekhbahadur' )
		),
		'youtube' => array(
			'id' => 'youtube',
			'title' => esc_html__( 'YouTube', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.youtube.com/', 'mekhbahadur' )
		),
		'github' => array(
			'id' => 'github',
			'title' => esc_html__( 'Github', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.github.com/', 'mekhbahadur' )
		),
		'stackoverflow' => array(
			'id' => 'stackoverflow',
			'title' => esc_html__( 'Stackoverflow', 'mekhbahadur' ),
			'default' => esc_html__( 'https://www.stackoverflow.com/', 'mekhbahadur' )
		)
	);
	$i = 1;

	foreach( $socials as $social ) {
		$wp_customize->add_setting( $social['id'], 
			array(
				'default' => $social['default'],
				'type' => 'theme_mod',
				'sanitize_callback' => 'esc_url_raw',
				'transport' => 'postMessage'
			) 
		);

		$wp_customize->add_control( $social['id'], 
			array(
				'label' => esc_html__( ' ', 'mekhbahadur' ) . $i . ' ' . $social['title'],
				'type' => 'text',
				'section' => 'social_setting',
				'settings' => $social['id'],
				'description' => esc_html__( 'This is the default social url. You can update with your own link now.', 'mekhbahadur' )
			) 
		);
		$i++;
	}

	$wp_customize->add_setting( 'footer_setting', 
		array(
			'default' => '1',
			'type' => 'theme_mod',
			'sanitize_callback' => 'sanitize_input',
			//'transport' => 'postMessage' 
		) 
	);

	$wp_customize->add_control( 'footer_setting', 
		array(
			'label' => esc_html__( 'Footer widgets', 'mekhbahadur' ),
			'type' => 'radio',
			'section' => 'footer',
			'settings' => 'footer_setting',
			'choices' => array(
				'1' => esc_html__( 'Footer one', 'mekhbahadur' ),
				'2' => esc_html__( 'Footer two', 'mekhbahadur' ),
				'3' => esc_html__( 'Footer three', 'mekhbahadur' ),
				'4' => esc_html__( 'Footer four', 'mekhbahadur' )
			)
		) 
	);

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', 
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'mekhbahadur_customize_partial_blogname',
			) 
		);
		$wp_customize->selective_refresh->add_partial( 'blogdescription', 
			array(
				'selector'        => '.site-description',
				'render_callback' => 'mekhbahadur_customize_partial_blogdescription',
			) 
		);
	}
}
add_action( 'customize_register', 'mekhbahadur_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function mekhbahadur_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function mekhbahadur_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function mekhbahadur_customize_preview_js() {
	wp_enqueue_script( 'mekhbahadur-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'jquery', 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'mekhbahadur_customize_preview_js' );

function sanitize_input( $input ) {
	if( !empty( $input ) ) {
		return $input;
	} else {
		return '';
	}
}

function mekhbahadur_icons() {
	return array(
		'fa fa-clock' => esc_html__( ' Clock', 'mekhbahadur'), 
        'fa fa-500px' => esc_html__( ' 500px', 'mekhbahadur'), 
        'fa fa-amazon' => esc_html__( ' amazon', 'mekhbahadur'), 
        'fa fa-balance-scale' => esc_html__( ' balance-scale', 'mekhbahadur'), 
        'fa fa-battery-0' => esc_html__( ' battery-0', 'mekhbahadur'), 
        'fa fa-battery-1' => esc_html__( ' battery-1', 'mekhbahadur'), 
        'fa fa-battery-2' => esc_html__( ' battery-2', 'mekhbahadur'), 
        'fa fa-battery-3' => esc_html__( ' battery-3', 'mekhbahadur'), 
        'fa fa-battery-4' => esc_html__( ' battery-4', 'mekhbahadur'), 
        'fa fa-battery-empty' => esc_html__( ' battery-empty', 'mekhbahadur'), 
        'fa fa-battery-full' => esc_html__( ' battery-full', 'mekhbahadur'), 
        'fa fa-battery-half' => esc_html__( ' battery-half', 'mekhbahadur'), 
        'fa fa-battery-quarter' => esc_html__( ' battery-quarter', 'mekhbahadur'), 
        'fa fa-battery-three-quarters' => esc_html__( ' battery-three-quarters', 'mekhbahadur'), 
        'fa fa-black-tie' => esc_html__( ' black-tie', 'mekhbahadur'), 
        'fa fa-calendar-check-o' => esc_html__( ' calendar-check-o', 'mekhbahadur'), 
        'fa fa-calendar-minus-o' => esc_html__( ' calendar-minus-o', 'mekhbahadur'), 
        'fa fa-calendar-plus-o' => esc_html__( ' calendar-plus-o', 'mekhbahadur'), 
        'fa fa-calendar-times-o' => esc_html__( ' calendar-times-o', 'mekhbahadur'), 
        'fa fa-cc-diners-club' => esc_html__( ' cc-diners-club', 'mekhbahadur'), 
        'fa fa-cc-jcb' => esc_html__( ' cc-jcb', 'mekhbahadur'), 
        'fa fa-chrome' => esc_html__( ' chrome', 'mekhbahadur'), 
        'fa fa-clone' => esc_html__( ' clone', 'mekhbahadur'), 
        'fa fa-commenting' => esc_html__( ' commenting', 'mekhbahadur'), 
        'fa fa-commenting-o' => esc_html__( ' commenting-o', 'mekhbahadur'), 
        'fa fa-contao' => esc_html__( ' contao', 'mekhbahadur'), 
        'fa fa-creative-commons' => esc_html__( ' creative-commons', 'mekhbahadur'), 
        'fa fa-expeditedssl' => esc_html__( ' expeditedssl', 'mekhbahadur'), 
        'fa fa-firefox' => esc_html__( ' firefox', 'mekhbahadur'), 
        'fa fa-fonticons' => esc_html__( ' fonticons', 'mekhbahadur'), 
        'fa fa-genderless' => esc_html__( ' genderless', 'mekhbahadur'), 
        'fa fa-get-pocket' => esc_html__( ' get-pocket', 'mekhbahadur'), 
        'fa fa-gg' => esc_html__( ' gg', 'mekhbahadur'), 
        'fa fa-gg-circle' => esc_html__( ' gg-circle', 'mekhbahadur'), 
        'fa fa-hand-grab-o' => esc_html__( ' hand-grab-o', 'mekhbahadur'), 
        'fa fa-hand-lizard-o' => esc_html__( ' hand-lizard-o', 'mekhbahadur'), 
        'fa fa-hand-paper-o' => esc_html__( ' hand-paper-o', 'mekhbahadur'), 
        'fa fa-hand-peace-o' => esc_html__( ' hand-peace-o', 'mekhbahadur'), 
        'fa fa-hand-pointer-o' => esc_html__( ' hand-pointer-o', 'mekhbahadur'), 
        'fa fa-hand-rock-o' => esc_html__( ' hand-rock-o', 'mekhbahadur'), 
        'fa fa-hand-scissors-o' => esc_html__( ' hand-scissors-o', 'mekhbahadur'), 
        'fa fa-hand-spock-o' => esc_html__( ' hand-spock-o', 'mekhbahadur'), 
        'fa fa-hand-stop-o' => esc_html__( ' hand-stop-o', 'mekhbahadur'), 
        'fa fa-hourglass' => esc_html__( ' hourglass', 'mekhbahadur'), 
        'fa fa-hourglass-1' => esc_html__( ' hourglass-1', 'mekhbahadur'), 
        'fa fa-hourglass-2' => esc_html__( ' hourglass-2', 'mekhbahadur'), 
        'fa fa-hourglass-3' => esc_html__( ' hourglass-3', 'mekhbahadur'), 
        'fa fa-hourglass-end' => esc_html__( ' hourglass-end', 'mekhbahadur'), 
        'fa fa-hourglass-half' => esc_html__( ' hourglass-half', 'mekhbahadur'), 
        'fa fa-hourglass-o' => esc_html__( ' hourglass-o', 'mekhbahadur'), 
        'fa fa-hourglass-start' => esc_html__( ' hourglass-start', 'mekhbahadur'), 
        'fa fa-houzz' => esc_html__( ' houzz', 'mekhbahadur'), 
        'fa fa-i-cursor' => esc_html__( ' i-cursor', 'mekhbahadur'), 
        'fa fa-industry' => esc_html__( ' industry', 'mekhbahadur'), 
        'fa fa-internet-explorer' => esc_html__( ' internet-explorer', 'mekhbahadur'), 
        'fa fa-map' => esc_html__( ' map', 'mekhbahadur'), 
        'fa fa-map-o' => esc_htmlesc_html__( ' map-o', 'mekhbahadur'), 
        'fa fa-map-pin' => esc_htmlesc_html__( ' map-pin', 'mekhbahadur'), 
        'fa fa-map-signs' => esc_htmlesc_html__( ' map-signs', 'mekhbahadur'), 
        'fa fa-mouse-pointer' => esc_html__( ' mouse-pointer', 'mekhbahadur'), 
        'fa fa-object-group' => esc_html__( ' object-group', 'mekhbahadur'), 
        'fa fa-object-ungroup' => esc_html__( ' object-ungroup', 'mekhbahadur'), 
        'fa fa-odnoklassniki' => esc_html__( ' odnoklassniki', 'mekhbahadur'), 
        'fa fa-odnoklassniki-square' => esc_html__( ' odnoklassniki-square', 'mekhbahadur'), 
        'fa fa-opencart' => esc_html__( ' opencart', 'mekhbahadur'), 
        'fa fa-opera' => esc_html__( ' opera', 'mekhbahadur'), 
        'fa fa-optin-monster' => esc_html__( ' optin-monster', 'mekhbahadur'), 
        'fa fa-registered' => __( ' registered', 'mekhbahadur'), 
        'fa fa-safari' => __( ' safari', 'mekhbahadur'), 
        'fa fa-sticky-note' => __( ' sticky-note', 'mekhbahadur'), 
        'fa fa-sticky-note-o' => __( ' sticky-note-o', 'mekhbahadur'), 
        'fa fa-television' => __( ' television', 'mekhbahadur'), 
        'fa fa-trademark' => esc_html__( ' trademark', 'mekhbahadur'), 
        'fa fa-tripadvisor' => esc_html__( ' tripadvisor', 'mekhbahadur'), 
        'fa fa-tv' => esc_html__( ' tv', 'mekhbahadur'), 
        'fa fa-vimeo' => esc_htmlesc_html__( ' vimeo', 'mekhbahadur'), 
        'fa fa-wikipedia-w' => esc_htmlesc_html__( ' wikipedia-w', 'mekhbahadur'), 
        'fa fa-y-combinator' => esc_htmlesc_html__( ' y-combinator', 'mekhbahadur'), 
        'fa fa-yc' => esc_htmlesc_html__( ' yc', 'mekhbahadur'), 
        'fa fa-adjust' => esc_html__( ' adjust', 'mekhbahadur'), 
        'fa fa-anchor' => esc_html__( ' anchor', 'mekhbahadur'), 
        'fa fa-archive' => esc_html__( ' archive', 'mekhbahadur'), 
        'fa fa-area-chart' => esc_html__( ' area-chart', 'mekhbahadur'), 
        'fa fa-arrows' => esc_html__( ' arrows', 'mekhbahadur'), 
        'fa fa-arrows-h' => esc_html__( ' arrows-h', 'mekhbahadur'), 
        'fa fa-arrows-v' => esc_html__( ' arrows-v', 'mekhbahadur'), 
        'fa fa-asterisk' => esc_html__( ' asterisk', 'mekhbahadur'), 
        'fa fa-at' => esc_html__( ' at', 'mekhbahadur'), 
        'fa fa-automobile' => esc_html__( ' automobile', 'mekhbahadur'), 
        'fa fa-balance-scale' => esc_html__( ' balance-scale', 'mekhbahadur'), 
        'fa fa-ban' => esc_html__( ' ban', 'mekhbahadur'), 
        'fa fa-bank' => esc_html__( ' bank', 'mekhbahadur'), 
        'fa fa-bar-chart' => esc_html__( ' bar-chart', 'mekhbahadur'), 
        'fa fa-bar-chart-o' => esc_html__( ' bar-chart-o', 'mekhbahadur'), 
        'fa fa-barcode' => esc_html__( ' barcode', 'mekhbahadur'), 
        'fa fa-bars' => esc_html__( ' bars', 'mekhbahadur'), 
        'fa fa-battery-0' => esc_html__( ' battery-0', 'mekhbahadur'), 
        'fa fa-battery-1' => esc_html__( ' battery-1', 'mekhbahadur'), 
        'fa fa-battery-2' => esc_html__( ' battery-2', 'mekhbahadur'), 
        'fa fa-battery-3' => esc_html__( ' battery-3', 'mekhbahadur'), 
        'fa fa-battery-4' => esc_html__( ' battery-4', 'mekhbahadur'), 
        'fa fa-battery-empty' => esc_html__( ' battery-empty', 'mekhbahadur'), 
        'fa fa-battery-full' => esc_html__( ' battery-full', 'mekhbahadur'), 
        'fa fa-battery-half' => esc_html__( ' battery-half', 'mekhbahadur'), 
        'fa fa-battery-quarter' => esc_html__( ' battery-quarter', 'mekhbahadur'), 
        'fa fa-battery-three-quarters' => esc_html__( ' battery-three-quarters', 'mekhbahadur'), 
        'fa fa-bed' => esc_html__( ' bed', 'mekhbahadur'), 
        'fa fa-beer' => esc_html__( ' beer', 'mekhbahadur'), 
        'fa fa-bell' => esc_html__( ' bell', 'mekhbahadur'), 
        'fa fa-bell-o' => esc_html__( ' bell-o', 'mekhbahadur'), 
        'fa fa-bell-slash' => esc_html__( ' bell-slash', 'mekhbahadur'), 
        'fa fa-bell-slash-o' => esc_html__( ' bell-slash-o', 'mekhbahadur'), 
        'fa fa-bicycle' => esc_html__( ' bicycle', 'mekhbahadur'), 
        'fa fa-binoculars' => esc_html__( ' binoculars', 'mekhbahadur'), 
        'fa fa-birthday-cake' => esc_html__( ' birthday-cake', 'mekhbahadur'), 
        'fa fa-bolt' => esc_html__( ' bolt', 'mekhbahadur'), 
        'fa fa-bomb' => esc_html__( ' bomb', 'mekhbahadur'), 
        'fa fa-book' => esc_html__( ' book', 'mekhbahadur'), 
        'fa fa-bookmark' => esc_html__( ' bookmark', 'mekhbahadur'), 
        'fa fa-bookmark-o' => esc_html__( ' bookmark-o', 'mekhbahadur'), 
        'fa fa-briefcase' => esc_html__( ' briefcase', 'mekhbahadur'), 
        'fa fa-bug' => esc_html__( ' bug', 'mekhbahadur'), 
        'fa fa-building' => esc_html__( ' building', 'mekhbahadur'), 
        'fa fa-building-o' => esc_html__( ' building-o', 'mekhbahadur'), 
        'fa fa-bullhorn' => esc_html__( ' bullhorn', 'mekhbahadur'), 
        'fa fa-bullseye' => esc_html__( ' bullseye', 'mekhbahadur'), 
        'fa fa-bus' => esc_html__( ' bus', 'mekhbahadur'), 
        'fa fa-cab' => esc_html__( ' cab', 'mekhbahadur'), 
        'fa fa-calculator' => esc_html__( ' calculator', 'mekhbahadur'), 
        'fa fa-calendar' => esc_html__( ' calendar', 'mekhbahadur'), 
        'fa fa-calendar-check-o' => esc_html__( ' calendar-check-o', 'mekhbahadur'), 
        'fa fa-calendar-minus-o' => esc_html__( ' calendar-minus-o', 'mekhbahadur'), 
        'fa fa-calendar-o' => esc_html__( ' calendar-o', 'mekhbahadur'), 
        'fa fa-calendar-plus-o' => esc_html__( ' calendar-plus-o', 'mekhbahadur'), 
        'fa fa-calendar-times-o' => esc_html__( ' calendar-times-o', 'mekhbahadur'), 
        'fa fa-camera' => esc_html__( ' camera', 'mekhbahadur'), 
        'fa fa-camera-retro' => esc_html__( ' camera-retro', 'mekhbahadur'), 
        'fa fa-car' => esc_html__( ' car', 'mekhbahadur'), 
        'fa fa-caret-square-o-down' => esc_html__( ' caret-square-o-down', 'mekhbahadur'), 
        'fa fa-caret-square-o-left' => esc_html__( ' caret-square-o-left', 'mekhbahadur'), 
        'fa fa-caret-square-o-right' => esc_html__( ' caret-square-o-right', 'mekhbahadur'), 
        'fa fa-caret-square-o-up' => esc_html__( ' caret-square-o-up', 'mekhbahadur'), 
        'fa fa-cart-arrow-down' => esc_html__( ' cart-arrow-down', 'mekhbahadur'), 
        'fa fa-cart-plus' => esc_html__( ' cart-plus', 'mekhbahadur'), 
        'fa fa-cc' => esc_html__( ' cc', 'mekhbahadur'), 
        'fa fa-certificate' => esc_html__( ' certificate', 'mekhbahadur'), 
        'fa fa-check' => esc_html__( ' check', 'mekhbahadur'), 
        'fa fa-check-circle' => esc_html__( ' check-circle', 'mekhbahadur'), 
        'fa fa-check-circle-o' => esc_html__( ' check-circle-o', 'mekhbahadur'), 
        'fa fa-check-square' => esc_html__( ' check-square', 'mekhbahadur'), 
        'fa fa-check-square-o' => esc_html__( ' check-square-o', 'mekhbahadur'), 
        'fa fa-child' => esc_html__( ' child', 'mekhbahadur'), 
        'fa fa-circle' => esc_html__( ' circle', 'mekhbahadur'), 
        'fa fa-circle-o' => esc_html__( ' circle-o', 'mekhbahadur'), 
        'fa fa-circle-o-notch' => esc_html__( ' circle-o-notch', 'mekhbahadur'), 
        'fa fa-circle-thin' => esc_html__( ' circle-thin', 'mekhbahadur'), 
        'fa fa-clock-o' => esc_html__( ' clock-o', 'mekhbahadur'), 
        'fa fa-clone' => esc_html__( ' clone', 'mekhbahadur'), 
        'fa fa-close' => esc_html__( ' close', 'mekhbahadur'), 
        'fa fa-cloud' => esc_html__( ' cloud', 'mekhbahadur'), 
        'fa fa-cloud-download' => esc_html__( ' cloud-download', 'mekhbahadur'), 
        'fa fa-cloud-upload' => esc_html__( ' cloud-upload', 'mekhbahadur'), 
        'fa fa-code' => esc_html__( ' code', 'mekhbahadur'), 
        'fa fa-code-fork' => esc_html__( ' code-fork', 'mekhbahadur'), 
        'fa fa-coffee' => esc_html__( ' coffee', 'mekhbahadur'), 
        'fa fa-cog' => esc_html__( ' cog', 'mekhbahadur'), 
        'fa fa-cogs' => esc_html__( ' cogs', 'mekhbahadur'), 
        'fa fa-comment' => esc_html__( ' comment', 'mekhbahadur'), 
        'fa fa-comment-o' => esc_html__( ' comment-o', 'mekhbahadur'), 
        'fa fa-commenting' => esc_html__( ' commenting', 'mekhbahadur'), 
        'fa fa-commenting-o' => esc_html__( ' commenting-o', 'mekhbahadur'), 
        'fa fa-comments' => esc_html__( ' comments', 'mekhbahadur'), 
        'fa fa-comments-o' => esc_html__( ' comments-o', 'mekhbahadur'), 
        'fa fa-compass' => esc_html__( ' compass', 'mekhbahadur'), 
        'fa fa-copyright' => esc_html__( ' copyright', 'mekhbahadur'), 
        'fa fa-creative-commons' => esc_html__( ' creative-commons', 'mekhbahadur'), 
        'fa fa-credit-card' => esc_html__( ' credit-card', 'mekhbahadur'), 
        'fa fa-crop' => esc_html__( ' crop', 'mekhbahadur'), 
        'fa fa-crosshairs' => esc_html__( ' crosshairs', 'mekhbahadur'), 
        'fa fa-cube' => esc_html__( ' cube', 'mekhbahadur'), 
        'fa fa-cubes' => esc_html__( ' cubes', 'mekhbahadur'), 
        'fa fa-cutlery' => esc_html__( ' cutlery', 'mekhbahadur'), 
        'fa fa-dashboard' => esc_html__( ' dashboard', 'mekhbahadur'), 
        'fa fa-database' => esc_html__( ' database', 'mekhbahadur'), 
        'fa fa-desktop' => esc_html__( ' desktop', 'mekhbahadur'), 
        'fa fa-diamond' => esc_html__( ' diamond', 'mekhbahadur'), 
        'fa fa-dot-circle-o' => esc_html__( ' dot-circle-o', 'mekhbahadur'), 
        'fa fa-download' => esc_html__( ' download', 'mekhbahadur'), 
        'fa fa-edit' => esc_html__( ' edit', 'mekhbahadur'), 
        'fa fa-ellipsis-h' => esc_html__( ' ellipsis-h', 'mekhbahadur'), 
        'fa fa-ellipsis-v' => esc_html__( ' ellipsis-v', 'mekhbahadur'), 
        'fa fa-envelope' => esc_html__( ' envelope', 'mekhbahadur'), 
        'fa fa-envelope-o' => esc_html__( ' envelope-o', 'mekhbahadur'), 
        'fa fa-envelope-square' => esc_html__( ' envelope-square', 'mekhbahadur'), 
        'fa fa-eraser' => esc_html__( ' eraser', 'mekhbahadur'), 
        'fa fa-exchange' => esc_html__( ' exchange', 'mekhbahadur'), 
        'fa fa-exclamation' => esc_html__( ' exclamation', 'mekhbahadur'), 
        'fa fa-exclamation-circle' => esc_html__( ' exclamation-circle', 'mekhbahadur'), 
        'fa fa-exclamation-triangle' => esc_html__( ' exclamation-triangle', 'mekhbahadur'), 
        'fa fa-external-link' => esc_html__( ' external-link', 'mekhbahadur'), 
        'fa fa-external-link-square' => esc_html__( ' external-link-square', 'mekhbahadur'), 
        'fa fa-eye' => esc_html__( ' eye', 'mekhbahadur'), 
        'fa fa-eye-slash' => esc_html__( ' eye-slash', 'mekhbahadur'), 
        'fa fa-eyedropper' => esc_html__( ' eyedropper', 'mekhbahadur'), 
        'fa fa-fax' => esc_html__( ' fax', 'mekhbahadur'), 
        'fa fa-feed' => esc_html__( ' feed', 'mekhbahadur'), 
        'fa fa-female' => esc_html__( ' female', 'mekhbahadur'), 
        'fa fa-fighter-jet' => esc_html__( ' fighter-jet', 'mekhbahadur'), 
        'fa fa-file-archive-o' => esc_html__( ' file-archive-o', 'mekhbahadur'), 
        'fa fa-file-audio-o' => esc_html__( ' file-audio-o', 'mekhbahadur'), 
        'fa fa-file-code-o' => esc_html__( ' file-code-o', 'mekhbahadur'), 
        'fa fa-file-excel-o' => esc_html__( ' file-excel-o', 'mekhbahadur'), 
        'fa fa-file-image-o' => esc_html__( ' file-image-o', 'mekhbahadur'), 
        'fa fa-file-movie-o' => esc_html__( ' file-movie-o', 'mekhbahadur'), 
        'fa fa-file-pdf-o' => esc_html__( ' file-pdf-o', 'mekhbahadur'), 
        'fa fa-file-photo-o' => esc_html__( ' file-photo-o', 'mekhbahadur'), 
        'fa fa-file-picture-o' => esc_html__( ' file-picture-o', 'mekhbahadur'), 
        'fa fa-file-powerpoint-o' => esc_html__( ' file-powerpoint-o', 'mekhbahadur'), 
        'fa fa-file-sound-o' => esc_html__( ' file-sound-o', 'mekhbahadur'), 
        'fa fa-file-video-o' => esc_html__( ' file-video-o', 'mekhbahadur'), 
        'fa fa-file-word-o' => esc_html__( ' file-word-o', 'mekhbahadur'), 
        'fa fa-file-zip-o' => esc_html__( ' file-zip-o', 'mekhbahadur'), 
        'fa fa-film' => esc_html__( ' film', 'mekhbahadur'), 
        'fa fa-filter' => esc_html__( ' filter', 'mekhbahadur'), 
        'fa fa-fire' => esc_html__( ' fire', 'mekhbahadur'), 
        'fa fa-fire-extinguisher' => esc_html__( ' fire-extinguisher', 'mekhbahadur'), 
        'fa fa-flag' => esc_html__( ' flag', 'mekhbahadur'), 
        'fa fa-flag-checkered' => esc_html__( ' flag-checkered', 'mekhbahadur'), 
        'fa fa-flag-o' => esc_html__( ' flag-o', 'mekhbahadur'), 
        'fa fa-flash' => esc_html__( ' flash', 'mekhbahadur'), 
        'fa fa-flask' => esc_html__( ' flask', 'mekhbahadur'), 
        'fa fa-folder' => esc_html__( ' folder', 'mekhbahadur'), 
        'fa fa-folder-o' => esc_html__( ' folder-o', 'mekhbahadur'), 
        'fa fa-folder-open' => esc_html__( ' folder-open', 'mekhbahadur'), 
        'fa fa-folder-open-o' => esc_html__( ' folder-open-o', 'mekhbahadur'), 
        'fa fa-frown-o' => esc_html__( ' frown-o', 'mekhbahadur'), 
        'fa fa-futbol-o' => esc_html__( ' futbol-o', 'mekhbahadur'), 
        'fa fa-gamepad' => esc_html__( ' gamepad', 'mekhbahadur'), 
        'fa fa-gavel' => esc_html__( ' gavel', 'mekhbahadur'), 
        'fa fa-gear' => esc_html__( ' gear', 'mekhbahadur'), 
        'fa fa-gears' => esc_html__( ' gears', 'mekhbahadur'), 
        'fa fa-gift' => esc_html__( ' gift', 'mekhbahadur'), 
        'fa fa-glass' => esc_html__( ' glass', 'mekhbahadur'), 
        'fa fa-globe' => esc_html__( ' globe', 'mekhbahadur'), 
        'fa fa-graduation-cap' => esc_html__( ' graduation-cap', 'mekhbahadur'), 
        'fa fa-group' => esc_html__( ' group', 'mekhbahadur'), 
        'fa fa-hand-grab-o' => esc_html__( ' hand-grab-o', 'mekhbahadur'), 
        'fa fa-hand-lizard-o' => esc_html__( ' hand-lizard-o', 'mekhbahadur'), 
        'fa fa-hand-paper-o' => esc_html__( ' hand-paper-o', 'mekhbahadur'), 
        'fa fa-hand-peace-o' => esc_html__( ' hand-peace-o', 'mekhbahadur'), 
        'fa fa-hand-pointer-o' => esc_html__( ' hand-pointer-o', 'mekhbahadur'), 
        'fa fa-hand-rock-o' => esc_html__( ' hand-rock-o', 'mekhbahadur'), 
        'fa fa-hand-scissors-o' => esc_html__( ' hand-scissors-o', 'mekhbahadur'), 
        'fa fa-hand-spock-o' => esc_html__( ' hand-spock-o', 'mekhbahadur'), 
        'fa fa-hand-stop-o' => esc_html__( ' hand-stop-o', 'mekhbahadur'), 
        'fa fa-hdd-o' => esc_html__( ' hdd-o', 'mekhbahadur'), 
        'fa fa-headphones' => esc_html__( ' headphones', 'mekhbahadur'), 
        'fa fa-heart' => esc_html__( ' heart', 'mekhbahadur'), 
        'fa fa-heart-o' => esc_html__( ' heart-o', 'mekhbahadur'), 
        'fa fa-heartbeat' => esc_html__( ' heartbeat', 'mekhbahadur'), 
        'fa fa-history' => esc_html__( ' history', 'mekhbahadur'), 
        'fa fa-home' => esc_html__( ' home', 'mekhbahadur'), 
        'fa fa-hotel' => esc_html__( ' hotel', 'mekhbahadur'), 
        'fa fa-hourglass' => esc_html__( ' hourglass', 'mekhbahadur'), 
        'fa fa-hourglass-1' => esc_html__( ' hourglass-1', 'mekhbahadur'), 
        'fa fa-hourglass-2' => esc_html__( ' hourglass-2', 'mekhbahadur'), 
        'fa fa-hourglass-3' => esc_html__( ' hourglass-3', 'mekhbahadur'), 
        'fa fa-hourglass-end' => esc_html__( ' hourglass-end', 'mekhbahadur'), 
        'fa fa-hourglass-half' => esc_html__( ' hourglass-half', 'mekhbahadur'), 
        'fa fa-hourglass-o' => esc_html__( ' hourglass-o', 'mekhbahadur'), 
        'fa fa-hourglass-start' => esc_html__( ' hourglass-start', 'mekhbahadur'), 
        'fa fa-i-cursor' => esc_html__( ' i-cursor', 'mekhbahadur'), 
        'fa fa-image' => esc_html__( ' image', 'mekhbahadur'), 
        'fa fa-inbox' => esc_html__( ' inbox', 'mekhbahadur'), 
        'fa fa-industry' => esc_html__( ' industry', 'mekhbahadur'), 
        'fa fa-info' => esc_html__( ' info', 'mekhbahadur'), 
        'fa fa-info-circle' => esc_html__( ' info-circle', 'mekhbahadur'), 
        'fa fa-institution' => esc_html__( ' institution', 'mekhbahadur'), 
        'fa fa-key' => esc_html__( ' key', 'mekhbahadur'), 
        'fa fa-keyboard-o' => esc_html__( ' keyboard-o', 'mekhbahadur'), 
        'fa fa-language' => esc_html__( ' language', 'mekhbahadur'), 
        'fa fa-laptop' => esc_html__( ' laptop', 'mekhbahadur'), 
        'fa fa-leaf' => esc_html__( ' leaf', 'mekhbahadur'), 
        'fa fa-legal' => esc_html__( ' legal', 'mekhbahadur'), 
        'fa fa-lemon-o' => esc_html__( ' lemon-o', 'mekhbahadur'), 
        'fa fa-level-down' => esc_html__( ' level-down', 'mekhbahadur'), 
        'fa fa-level-up' => esc_html__( ' level-up', 'mekhbahadur'), 
        'fa fa-life-bouy' => esc_html__( ' life-bouy', 'mekhbahadur'), 
        'fa fa-life-buoy' => esc_html__( ' life-buoy', 'mekhbahadur'), 
        'fa fa-life-ring' => esc_html__( ' life-ring', 'mekhbahadur'), 
        'fa fa-life-saver' => esc_html__( ' life-saver', 'mekhbahadur'), 
        'fa fa-lightbulb-o' => esc_html__( ' lightbulb-o', 'mekhbahadur'), 
        'fa fa-line-chart' => esc_html__( ' line-chart', 'mekhbahadur'), 
        'fa fa-location-arrow' => esc_html__( ' location-arrow', 'mekhbahadur'), 
        'fa fa-lock' => esc_html__( ' lock', 'mekhbahadur'), 
        'fa fa-magic' => esc_html__( ' magic', 'mekhbahadur'), 
        'fa fa-magnet' => esc_html__( ' magnet', 'mekhbahadur'), 
        'fa fa-mail-forward' => esc_html__( ' mail-forward', 'mekhbahadur'), 
        'fa fa-mail-reply' => esc_html__( ' mail-reply', 'mekhbahadur'), 
        'fa fa-mail-reply-all' => esc_html__( ' mail-reply-all', 'mekhbahadur'), 
        'fa fa-male' => esc_html__( ' male', 'mekhbahadur'), 
        'fa fa-map' => esc_html__( ' map', 'mekhbahadur'), 
        'fa fa-map-marker' => esc_html__( ' map-marker', 'mekhbahadur'), 
        'fa fa-map-o' => esc_html__( ' map-o', 'mekhbahadur'), 
        'fa fa-map-pin' => esc_html__( ' map-pin', 'mekhbahadur'), 
        'fa fa-map-signs' => esc_html__( ' map-signs', 'mekhbahadur'), 
        'fa fa-meh-o' => esc_html__( ' meh-o', 'mekhbahadur'), 
        'fa fa-microphone' => esc_html__( ' microphone', 'mekhbahadur'), 
        'fa fa-microphone-slash' => esc_html__( ' microphone-slash', 'mekhbahadur'), 
        'fa fa-minus' => esc_html__( ' minus', 'mekhbahadur'), 
        'fa fa-minus-circle' => esc_html__( ' minus-circle', 'mekhbahadur'), 
        'fa fa-minus-square' => esc_html__( ' minus-square', 'mekhbahadur'), 
        'fa fa-minus-square-o' => esc_html__( ' minus-square-o', 'mekhbahadur'), 
        'fa fa-mobile' => esc_html__( ' mobile', 'mekhbahadur'), 
        'fa fa-mobile-phone' => esc_html__( ' mobile-phone', 'mekhbahadur'), 
        'fa fa-money' => esc_html__( ' money', 'mekhbahadur'), 
        'fa fa-moon-o' => esc_html__( ' moon-o', 'mekhbahadur'), 
        'fa fa-mortar-board' => esc_html__( ' mortar-board', 'mekhbahadur'), 
        'fa fa-motorcycle' => esc_html__( ' motorcycle', 'mekhbahadur'), 
        'fa fa-mouse-pointer' => esc_html__( ' mouse-pointer', 'mekhbahadur'), 
        'fa fa-music' => esc_html__( ' music', 'mekhbahadur'), 
        'fa fa-navicon' => esc_html__( ' navicon', 'mekhbahadur'), 
        'fa fa-newspaper-o' => esc_html__( ' newspaper-o', 'mekhbahadur'), 
        'fa fa-object-group' => esc_html__( ' object-group', 'mekhbahadur'), 
        'fa fa-object-ungroup' => esc_html__( ' object-ungroup', 'mekhbahadur'), 
        'fa fa-paint-brush' => esc_html__( ' paint-brush', 'mekhbahadur'), 
        'fa fa-paper-plane' => esc_html__( ' paper-plane', 'mekhbahadur'), 
        'fa fa-paper-plane-o' => esc_html__( ' paper-plane-o', 'mekhbahadur'), 
        'fa fa-paw' => esc_html__( ' paw', 'mekhbahadur'), 
        'fa fa-pencil' => esc_html__( ' pencil', 'mekhbahadur'), 
        'fa fa-pencil-square' => esc_html__( ' pencil-square', 'mekhbahadur'), 
        'fa fa-pencil-square-o' => esc_html__( ' pencil-square-o', 'mekhbahadur'), 
        'fa fa-phone' => esc_html__( ' phone', 'mekhbahadur'), 
        'fa fa-phone-square' => esc_html__( ' phone-square', 'mekhbahadur'), 
        'fa fa-photo' => esc_html__( ' photo', 'mekhbahadur'), 
        'fa fa-picture-o' => esc_html__( ' picture-o', 'mekhbahadur'), 
        'fa fa-pie-chart' => esc_html__( ' pie-chart', 'mekhbahadur'), 
        'fa fa-plane' => esc_html__( ' plane', 'mekhbahadur'), 
        'fa fa-plug' => esc_html__( ' plug', 'mekhbahadur'), 
        'fa fa-plus' => esc_html__( ' plus', 'mekhbahadur'), 
        'fa fa-plus-circle' => esc_html__( ' plus-circle', 'mekhbahadur'), 
        'fa fa-plus-square' => esc_html__( ' plus-square', 'mekhbahadur'), 
        'fa fa-plus-square-o' => esc_html__( ' plus-square-o', 'mekhbahadur'), 
        'fa fa-power-off' => esc_html__( ' power-off', 'mekhbahadur'), 
        'fa fa-print' => esc_html__( ' print', 'mekhbahadur'), 
        'fa fa-puzzle-piece' => esc_html__( ' puzzle-piece', 'mekhbahadur'), 
        'fa fa-qrcode' => esc_html__( ' qrcode', 'mekhbahadur'), 
        'fa fa-question' => esc_html__( ' question', 'mekhbahadur'), 
        'fa fa-question-circle' => esc_html__( ' question-circle', 'mekhbahadur'), 
        'fa fa-quote-left' => esc_html__( ' quote-left', 'mekhbahadur'), 
        'fa fa-quote-right' => esc_html__( ' quote-right', 'mekhbahadur'), 
        'fa fa-random' => esc_html__( ' random', 'mekhbahadur'), 
        'fa fa-recycle' => esc_html__( ' recycle', 'mekhbahadur'), 
        'fa fa-refresh' => esc_html__( ' refresh', 'mekhbahadur'), 
        'fa fa-registered' => esc_html__( ' registered', 'mekhbahadur'), 
        'fa fa-remove' => esc_html__( ' remove', 'mekhbahadur'), 
        'fa fa-reorder' => esc_html__( ' reorder', 'mekhbahadur'), 
        'fa fa-reply' => esc_html__( ' reply', 'mekhbahadur'), 
        'fa fa-reply-all' => esc_html__( ' reply-all', 'mekhbahadur'), 
        'fa fa-retweet' => esc_html__( ' retweet', 'mekhbahadur'), 
        'fa fa-road' => esc_html__( ' road', 'mekhbahadur'), 
        'fa fa-rocket' => esc_html__( ' rocket', 'mekhbahadur'), 
        'fa fa-rss' => esc_html__( ' rss', 'mekhbahadur'), 
        'fa fa-rss-square' => esc_html__( ' rss-square', 'mekhbahadur'), 
        'fa fa-search' => esc_html__( ' search', 'mekhbahadur'), 
        'fa fa-search-minus' => esc_html__( ' search-minus', 'mekhbahadur'), 
        'fa fa-search-plus' => esc_html__( ' search-plus', 'mekhbahadur'), 
        'fa fa-send' => esc_html__( ' send', 'mekhbahadur'), 
        'fa fa-send-o' => esc_html__( ' send-o', 'mekhbahadur'), 
        'fa fa-server' => esc_html__( ' server', 'mekhbahadur'), 
        'fa fa-share' => esc_html__( ' share', 'mekhbahadur'), 
        'fa fa-share-alt' => esc_html__( ' share-alt', 'mekhbahadur'), 
        'fa fa-share-alt-square' => esc_html__( ' share-alt-square', 'mekhbahadur'), 
        'fa fa-share-square' => esc_html__( ' share-square', 'mekhbahadur'), 
        'fa fa-share-square-o' => esc_html__( ' share-square-o', 'mekhbahadur'), 
        'fa fa-shield' => esc_html__( ' shield', 'mekhbahadur'), 
        'fa fa-ship' => esc_html__( ' ship', 'mekhbahadur'), 
        'fa fa-shopping-cart' => esc_html__( ' shopping-cart', 'mekhbahadur'), 
        'fa fa-sign-in' => esc_html__( ' sign-in', 'mekhbahadur'), 
        'fa fa-sign-out' => esc_html__( ' sign-out', 'mekhbahadur'), 
        'fa fa-signal' => esc_html__( ' signal', 'mekhbahadur'), 
        'fa fa-sitemap' => esc_html__( ' sitemap', 'mekhbahadur'), 
        'fa fa-sliders' => esc_html__( ' sliders', 'mekhbahadur'), 
        'fa fa-smile-o' => esc_html__( ' smile-o', 'mekhbahadur'), 
        'fa fa-soccer-ball-o' => esc_html__( ' soccer-ball-o', 'mekhbahadur'), 
        'fa fa-sort' => esc_html__( ' sort', 'mekhbahadur'), 
        'fa fa-sort-alpha-asc' => esc_html__( ' sort-alpha-asc', 'mekhbahadur'), 
        'fa fa-sort-alpha-desc' => esc_html__( ' sort-alpha-desc', 'mekhbahadur'), 
        'fa fa-sort-amount-asc' => esc_html__( ' sort-amount-asc', 'mekhbahadur'), 
        'fa fa-sort-amount-desc' => esc_html__( ' sort-amount-desc', 'mekhbahadur'), 
        'fa fa-sort-asc' => esc_html__( ' sort-asc', 'mekhbahadur'), 
        'fa fa-sort-desc' => esc_html__( ' sort-desc', 'mekhbahadur'), 
        'fa fa-sort-down' => esc_html__( ' sort-down', 'mekhbahadur'), 
        'fa fa-sort-numeric-asc' => esc_html__( ' sort-numeric-asc', 'mekhbahadur'), 
        'fa fa-sort-numeric-desc' => esc_html__( ' sort-numeric-desc', 'mekhbahadur'), 
        'fa fa-sort-up' => esc_html__( ' sort-up', 'mekhbahadur'), 
        'fa fa-space-shuttle' => esc_html__( ' space-shuttle', 'mekhbahadur'), 
        'fa fa-spinner' => esc_html__( ' spinner', 'mekhbahadur'), 
        'fa fa-spoon' => esc_html__( ' spoon', 'mekhbahadur'), 
        'fa fa-square' => esc_html__( ' square', 'mekhbahadur'), 
        'fa fa-square-o' => esc_html__( ' square-o', 'mekhbahadur'), 
        'fa fa-star' => esc_html__( ' star', 'mekhbahadur'), 
        'fa fa-star-half' => esc_html__( ' star-half', 'mekhbahadur'), 
        'fa fa-star-half-empty' => esc_html__( ' star-half-empty', 'mekhbahadur'), 
        'fa fa-star-half-full' => esc_html__( ' star-half-full', 'mekhbahadur'), 
        'fa fa-star-half-o' => esc_html__( ' star-half-o', 'mekhbahadur'), 
        'fa fa-star-o' => esc_html__( ' star-o', 'mekhbahadur'), 
        'fa fa-sticky-note' => esc_html__( ' sticky-note', 'mekhbahadur'), 
        'fa fa-sticky-note-o' => esc_html__( ' sticky-note-o', 'mekhbahadur'), 
        'fa fa-street-view' => esc_html__( ' street-view', 'mekhbahadur'), 
        'fa fa-suitcase' => esc_html__( ' suitcase', 'mekhbahadur'), 
        'fa fa-sun-o' => esc_html__( ' sun-o', 'mekhbahadur'), 
        'fa fa-support' => esc_html__( ' support', 'mekhbahadur'), 
        'fa fa-tablet' => esc_html__( ' tablet', 'mekhbahadur'), 
        'fa fa-tachometer' => esc_html__( ' tachometer', 'mekhbahadur'), 
        'fa fa-tag' => esc_html__( ' tag', 'mekhbahadur'), 
        'fa fa-tags' => esc_html__( ' tags', 'mekhbahadur'), 
        'fa fa-tasks' => esc_html__( ' tasks', 'mekhbahadur'), 
        'fa fa-taxi' => esc_html__( ' taxi', 'mekhbahadur'), 
        'fa fa-television' => esc_html__( ' television', 'mekhbahadur'), 
        'fa fa-terminal' => esc_html__( ' terminal', 'mekhbahadur'), 
        'fa fa-thumb-tack' => esc_html__( ' thumb-tack', 'mekhbahadur'), 
        'fa fa-thumbs-down' => esc_html__( ' thumbs-down', 'mekhbahadur'), 
        'fa fa-thumbs-o-down' => esc_html__( ' thumbs-o-down', 'mekhbahadur'), 
        'fa fa-thumbs-o-up' => esc_html__( ' thumbs-o-up', 'mekhbahadur'), 
        'fa fa-thumbs-up' => esc_html__( ' thumbs-up', 'mekhbahadur'), 
        'fa fa-ticket' => esc_html__( ' ticket', 'mekhbahadur'), 
        'fa fa-times' => esc_html__( ' times', 'mekhbahadur'), 
        'fa fa-times-circle' => esc_html__( ' times-circle', 'mekhbahadur'), 
        'fa fa-times-circle-o' => esc_html__( ' times-circle-o', 'mekhbahadur'), 
        'fa fa-tint' => esc_html__( ' tint', 'mekhbahadur'), 
        'fa fa-toggle-down' => esc_html__( ' toggle-down', 'mekhbahadur'), 
        'fa fa-toggle-left' => esc_html__( ' toggle-left', 'mekhbahadur'), 
        'fa fa-toggle-off' => esc_html__( ' toggle-off', 'mekhbahadur'), 
        'fa fa-toggle-on' => esc_html__( ' toggle-on', 'mekhbahadur'), 
        'fa fa-toggle-right' => esc_html__( ' toggle-right', 'mekhbahadur'), 
        'fa fa-toggle-up' => esc_html__( ' toggle-up', 'mekhbahadur'), 
        'fa fa-trademark' => esc_html__( ' trademark', 'mekhbahadur'), 
        'fa fa-trash' => esc_html__( ' trash', 'mekhbahadur'), 
        'fa fa-trash-o' => esc_html__( ' trash-o', 'mekhbahadur'), 
        'fa fa-tree' => esc_html__( ' tree', 'mekhbahadur'), 
        'fa fa-trophy' => esc_html__( ' trophy', 'mekhbahadur'), 
        'fa fa-truck' => esc_html__( ' truck', 'mekhbahadur'), 
        'fa fa-tty' => esc_html__( ' tty', 'mekhbahadur'), 
        'fa fa-tv' => esc_html__( ' tv', 'mekhbahadur'), 
        'fa fa-umbrella' => esc_html__( ' umbrella', 'mekhbahadur'), 
        'fa fa-university' => esc_html__( ' university', 'mekhbahadur'), 
        'fa fa-unlock' => esc_html__( ' unlock', 'mekhbahadur'), 
        'fa fa-unlock-alt' => esc_html__( ' unlock-alt', 'mekhbahadur'), 
        'fa fa-unsorted' => esc_html__( ' unsorted', 'mekhbahadur'), 
        'fa fa-upload' => esc_html__( ' upload', 'mekhbahadur'), 
        'fa fa-user' => esc_html__( ' user', 'mekhbahadur'), 
        'fa fa-user-plus' => esc_html__( ' user-plus', 'mekhbahadur'), 
        'fa fa-user-secret' => esc_html__( ' user-secret', 'mekhbahadur'), 
        'fa fa-user-times' => esc_html__( ' user-times', 'mekhbahadur'), 
        'fa fa-users' => esc_html__( ' users', 'mekhbahadur'), 
        'fa fa-video-camera' => esc_html__( ' video-camera', 'mekhbahadur'), 
        'fa fa-volume-down' => esc_html__( ' volume-down', 'mekhbahadur'), 
        'fa fa-volume-off' => esc_html__( ' volume-off', 'mekhbahadur'), 
        'fa fa-volume-up' => esc_html__( ' volume-up', 'mekhbahadur'), 
        'fa fa-warning' => esc_html__( ' warning', 'mekhbahadur'), 
        'fa fa-wheelchair' => esc_html__( ' wheelchair', 'mekhbahadur'), 
        'fa fa-wifi' => esc_html__( ' wifi', 'mekhbahadur'), 
        'fa fa-wrench' => esc_html__( ' wrench', 'mekhbahadur'), 
        'fa fa-hand-grab-o' => esc_html__( ' hand-grab-o', 'mekhbahadur'), 
        'fa fa-hand-lizard-o' => esc_html__( ' hand-lizard-o', 'mekhbahadur'), 
        'fa fa-hand-o-down' => esc_html__( ' hand-o-down', 'mekhbahadur'), 
        'fa fa-hand-o-left' => esc_html__( ' hand-o-left', 'mekhbahadur'), 
        'fa fa-hand-o-right' => esc_html__( ' hand-o-right', 'mekhbahadur'), 
        'fa fa-hand-o-up' => esc_html__( ' hand-o-up', 'mekhbahadur'), 
        'fa fa-hand-paper-o' => esc_html__( ' hand-paper-o', 'mekhbahadur'), 
        'fa fa-hand-peace-o' => esc_html__( ' hand-peace-o', 'mekhbahadur'), 
        'fa fa-hand-pointer-o' => esc_html__( ' hand-pointer-o', 'mekhbahadur'), 
        'fa fa-hand-rock-o' => esc_html__( ' hand-rock-o', 'mekhbahadur'), 
        'fa fa-hand-scissors-o' => esc_html__( ' hand-scissors-o', 'mekhbahadur'), 
        'fa fa-hand-spock-o' => esc_html__( ' hand-spock-o', 'mekhbahadur'), 
        'fa fa-hand-stop-o' => esc_html__( ' hand-stop-o', 'mekhbahadur'), 
        'fa fa-thumbs-down' => esc_html__( ' thumbs-down', 'mekhbahadur'), 
        'fa fa-thumbs-o-down' => esc_html__( ' thumbs-o-down', 'mekhbahadur'), 
        'fa fa-thumbs-o-up' => esc_html__( ' thumbs-o-up', 'mekhbahadur'), 
        'fa fa-thumbs-up' => esc_html__( ' thumbs-up', 'mekhbahadur'), 
        'fa fa-ambulance' => esc_html__( ' ambulance', 'mekhbahadur'), 
        'fa fa-automobile' => esc_html__( ' automobile', 'mekhbahadur'), 
        'fa fa-bicycle' => esc_html__( ' bicycle', 'mekhbahadur'), 
        'fa fa-bus' => esc_html__( ' bus', 'mekhbahadur'), 
        'fa fa-cab' => esc_html__( ' cab', 'mekhbahadur'), 
        'fa fa-car' => esc_html__( ' car', 'mekhbahadur'), 
        'fa fa-fighter-jet' => esc_html__( ' fighter-jet', 'mekhbahadur'), 
        'fa fa-motorcycle' => esc_html__( ' motorcycle', 'mekhbahadur'), 
        'fa fa-plane' => esc_html__( ' plane', 'mekhbahadur'), 
        'fa fa-rocket' => esc_html__( ' rocket', 'mekhbahadur'), 
        'fa fa-ship' => esc_html__( ' ship', 'mekhbahadur'), 
        'fa fa-space-shuttle' => esc_html__( ' space-shuttle', 'mekhbahadur'), 
        'fa fa-subway' => esc_html__( ' subway', 'mekhbahadur'), 
        'fa fa-taxi' => esc_html__( ' taxi', 'mekhbahadur'), 
        'fa fa-train' => esc_html__( ' train', 'mekhbahadur'), 
        'fa fa-truck' => esc_html__( ' truck', 'mekhbahadur'), 
        'fa fa-wheelchair' => esc_html__( ' wheelchair', 'mekhbahadur'), 
        'fa fa-genderless' => esc_html__( ' genderless', 'mekhbahadur'), 
        'fa fa-intersex' => esc_html__( ' intersex', 'mekhbahadur'), 
        'fa fa-mars' => esc_html__( ' mars', 'mekhbahadur'), 
        'fa fa-mars-double' => esc_html__( ' mars-double', 'mekhbahadur'), 
        'fa fa-mars-stroke' => esc_html__( ' mars-stroke', 'mekhbahadur'), 
        'fa fa-mars-stroke-h' => esc_html__( ' mars-stroke-h', 'mekhbahadur'), 
        'fa fa-mars-stroke-v' => esc_html__( ' mars-stroke-v', 'mekhbahadur'), 
        'fa fa-mercury' => esc_html__( ' mercury', 'mekhbahadur'), 
        'fa fa-neuter' => esc_html__( ' neuter', 'mekhbahadur'), 
        'fa fa-transgender' => esc_html__( ' transgender', 'mekhbahadur'), 
        'fa fa-transgender-alt' => esc_html__( ' transgender-alt', 'mekhbahadur'), 
        'fa fa-venus' => esc_html__( ' venus', 'mekhbahadur'), 
        'fa fa-venus-double' => esc_html__( ' venus-double', 'mekhbahadur'), 
        'fa fa-venus-mars' => esc_html__( ' venus-mars', 'mekhbahadur'), 
        'fa fa-file' => esc_html__( ' file', 'mekhbahadur'), 
        'fa fa-file-archive-o' => esc_html__( ' file-archive-o', 'mekhbahadur'), 
        'fa fa-file-audio-o' => esc_html__( ' file-audio-o', 'mekhbahadur'), 
        'fa fa-file-code-o' => esc_html__( ' file-code-o', 'mekhbahadur'), 
        'fa fa-file-excel-o' => esc_html__( ' file-excel-o', 'mekhbahadur'), 
        'fa fa-file-image-o' => esc_html__( ' file-image-o', 'mekhbahadur'), 
        'fa fa-file-movie-o' => esc_html__( ' file-movie-o', 'mekhbahadur'), 
        'fa fa-file-o' => esc_html__( ' file-o', 'mekhbahadur'), 
        'fa fa-file-pdf-o' => esc_html__( ' file-pdf-o', 'mekhbahadur'), 
        'fa fa-file-photo-o' => esc_html__( ' file-photo-o', 'mekhbahadur'), 
        'fa fa-file-picture-o' => esc_html__( ' file-picture-o', 'mekhbahadur'), 
        'fa fa-file-powerpoint-o' => esc_html__( ' file-powerpoint-o', 'mekhbahadur'), 
        'fa fa-file-sound-o' => esc_html__( ' file-sound-o', 'mekhbahadur'), 
        'fa fa-file-text' => esc_html__( ' file-text', 'mekhbahadur'), 
        'fa fa-file-text-o' => esc_html__( ' file-text-o', 'mekhbahadur'), 
        'fa fa-file-video-o' => esc_html__( ' file-video-o', 'mekhbahadur'), 
        'fa fa-file-word-o' => esc_html__( ' file-word-o', 'mekhbahadur'), 
        'fa fa-file-zip-o' => esc_html__( ' file-zip-o', 'mekhbahadur'), 
        'fa fa-circle-o-notch' => esc_html__( ' circle-o-notch', 'mekhbahadur'), 
        'fa fa-cog' => esc_html__( ' cog', 'mekhbahadur'), 
        'fa fa-gear' => esc_html__( ' gear', 'mekhbahadur'), 
        'fa fa-refresh' => esc_html__( ' refresh', 'mekhbahadur'), 
        'fa fa-spinner' => esc_html__( ' spinner', 'mekhbahadur'), 
        'fa fa-check-square' => esc_html__( ' check-square', 'mekhbahadur'), 
        'fa fa-check-square-o' => esc_html__( ' check-square-o', 'mekhbahadur'), 
        'fa fa-circle' => esc_html__( ' circle', 'mekhbahadur'), 
        'fa fa-circle-o' => esc_html__( ' circle-o', 'mekhbahadur'), 
        'fa fa-dot-circle-o' => esc_html__( ' dot-circle-o', 'mekhbahadur'), 
        'fa fa-minus-square' => esc_html__( ' minus-square', 'mekhbahadur'), 
        'fa fa-minus-square-o' => esc_html__( ' minus-square-o', 'mekhbahadur'), 
        'fa fa-plus-square' => esc_html__( ' plus-square', 'mekhbahadur'), 
        'fa fa-plus-square-o' => esc_html__( ' plus-square-o', 'mekhbahadur'), 
        'fa fa-square' => esc_html__( ' square', 'mekhbahadur'), 
        'fa fa-square-o' => esc_html__( ' square-o', 'mekhbahadur'), 
        'fa fa-cc-amex' => esc_html__( ' cc-amex', 'mekhbahadur'), 
        'fa fa-cc-diners-club' => esc_html__( ' cc-diners-club', 'mekhbahadur'), 
        'fa fa-cc-discover' => esc_html__( ' cc-discover', 'mekhbahadur'), 
        'fa fa-cc-jcb' => esc_html__( ' cc-jcb', 'mekhbahadur'), 
        'fa fa-cc-mastercard' => esc_html__( ' cc-mastercard', 'mekhbahadur'), 
        'fa fa-cc-paypal' => esc_html__( ' cc-paypal', 'mekhbahadur'), 
        'fa fa-cc-stripe' => esc_html__( ' cc-stripe', 'mekhbahadur'), 
        'fa fa-cc-visa' => esc_html__( ' cc-visa', 'mekhbahadur'), 
        'fa fa-credit-card' => esc_html__( ' credit-card', 'mekhbahadur'), 
        'fa fa-google-wallet' => esc_html__( ' google-wallet', 'mekhbahadur'), 
        'fa fa-paypal' => esc_html__( ' paypal', 'mekhbahadur'), 
        'fa fa-area-chart' => esc_html__( ' area-chart', 'mekhbahadur'), 
        'fa fa-bar-chart' => esc_html__( ' bar-chart', 'mekhbahadur'), 
        'fa fa-bar-chart-o' => esc_html__( ' bar-chart-o', 'mekhbahadur'), 
        'fa fa-line-chart' => esc_html__( ' line-chart', 'mekhbahadur'), 
        'fa fa-pie-chart' => esc_html__( ' pie-chart', 'mekhbahadur'), 
        'fa fa-bitcoin' => esc_html__( ' bitcoin', 'mekhbahadur'), 
        'fa fa-btc' => esc_html__( ' btc', 'mekhbahadur'), 
        'fa fa-cny' => esc_html__( ' cny', 'mekhbahadur'), 
        'fa fa-dollar' => esc_html__( ' dollar', 'mekhbahadur'), 
        'fa fa-eur' => esc_html__( ' eur', 'mekhbahadur'), 
        'fa fa-euro' => esc_html__( ' euro', 'mekhbahadur'), 
        'fa fa-gbp' => esc_html__( ' gbp', 'mekhbahadur'), 
        'fa fa-gg' => esc_html__( ' gg', 'mekhbahadur'), 
        'fa fa-gg-circle' => esc_html__( ' gg-circle', 'mekhbahadur'), 
        'fa fa-ils' => esc_html__( ' ils', 'mekhbahadur'), 
        'fa fa-inr' => esc_html__( ' inr', 'mekhbahadur'), 
        'fa fa-jpy' => esc_html__( ' jpy', 'mekhbahadur'), 
        'fa fa-krw' => esc_html__( ' krw', 'mekhbahadur'), 
        'fa fa-money' => esc_html__( ' money', 'mekhbahadur'), 
        'fa fa-rmb' => esc_html__( ' rmb', 'mekhbahadur'), 
        'fa fa-rouble' => esc_html__( ' rouble', 'mekhbahadur'), 
        'fa fa-rub' => esc_html__( ' rub', 'mekhbahadur'), 
        'fa fa-ruble' => esc_html__( ' ruble', 'mekhbahadur'), 
        'fa fa-rupee' => esc_html__( ' rupee', 'mekhbahadur'), 
        'fa fa-shekel' => esc_html__( ' shekel', 'mekhbahadur'), 
        'fa fa-sheqel' => esc_html__( ' sheqel', 'mekhbahadur'), 
        'fa fa-try' => esc_html__( ' try', 'mekhbahadur'), 
        'fa fa-turkish-lira' => esc_html__( ' turkish-lira', 'mekhbahadur'), 
        'fa fa-usd' => esc_html__( ' usd', 'mekhbahadur'), 
        'fa fa-won' => esc_html__( ' won', 'mekhbahadur'), 
        'fa fa-yen' => esc_html__( ' yen', 'mekhbahadur'), 
        'fa fa-align-center' => esc_html__( ' align-center', 'mekhbahadur'), 
        'fa fa-align-justify' => esc_html__( ' align-justify', 'mekhbahadur'), 
        'fa fa-align-left' => esc_html__( ' align-left', 'mekhbahadur'), 
        'fa fa-align-right' => esc_html__( ' align-right', 'mekhbahadur'), 
        'fa fa-bold' => esc_html__( ' bold', 'mekhbahadur'), 
        'fa fa-chain' => esc_html__( ' chain', 'mekhbahadur'), 
        'fa fa-chain-broken' => esc_html__( ' chain-broken', 'mekhbahadur'), 
        'fa fa-clipboard' => esc_html__( ' clipboard', 'mekhbahadur'), 
        'fa fa-columns' => esc_html__( ' columns', 'mekhbahadur'), 
        'fa fa-copy' => esc_html__( ' copy', 'mekhbahadur'), 
        'fa fa-cut' => esc_html__( ' cut', 'mekhbahadur'), 
        'fa fa-dedent' => esc_html__( ' dedent', 'mekhbahadur'), 
        'fa fa-eraser' => esc_html__( ' eraser', 'mekhbahadur'), 
        'fa fa-file' => esc_html__( ' file', 'mekhbahadur'), 
        'fa fa-file-o' => esc_html__( ' file-o', 'mekhbahadur'), 
        'fa fa-file-text' => esc_html__( ' file-text', 'mekhbahadur'), 
        'fa fa-file-text-o' => esc_html__( ' file-text-o', 'mekhbahadur'), 
        'fa fa-files-o' => esc_html__( ' files-o', 'mekhbahadur'), 
        'fa fa-floppy-o' => esc_html__( ' floppy-o', 'mekhbahadur'), 
        'fa fa-font' => esc_html__( ' font', 'mekhbahadur'), 
        'fa fa-header' => esc_html__( ' header', 'mekhbahadur'), 
        'fa fa-indent' => esc_html__( ' indent', 'mekhbahadur'), 
        'fa fa-italic' => esc_html__( ' italic', 'mekhbahadur'), 
        'fa fa-link' => esc_html__( ' link', 'mekhbahadur'), 
        'fa fa-list' => esc_html__( ' list', 'mekhbahadur'), 
        'fa fa-list-alt' => esc_html__( ' list-alt', 'mekhbahadur'), 
        'fa fa-list-ol' => esc_html__( ' list-ol', 'mekhbahadur'), 
        'fa fa-list-ul' => esc_html__( ' list-ul', 'mekhbahadur'), 
        'fa fa-outdent' => esc_html__( ' outdent', 'mekhbahadur'), 
        'fa fa-paperclip' => esc_html__( ' paperclip', 'mekhbahadur'), 
        'fa fa-paragraph' => esc_html__( ' paragraph', 'mekhbahadur'), 
        'fa fa-paste' => esc_html__( ' paste', 'mekhbahadur'), 
        'fa fa-repeat' => esc_html__( ' repeat', 'mekhbahadur'), 
        'fa fa-rotate-left' => esc_html__( ' rotate-left', 'mekhbahadur'), 
        'fa fa-rotate-right' => esc_html__( ' rotate-right', 'mekhbahadur'), 
        'fa fa-save' => esc_html__( ' save', 'mekhbahadur'), 
        'fa fa-scissors' => esc_html__( ' scissors', 'mekhbahadur'), 
        'fa fa-strikethrough' => esc_html__( ' strikethrough', 'mekhbahadur'), 
        'fa fa-subscript' => esc_html__( ' subscript', 'mekhbahadur'), 
        'fa fa-superscript' => esc_html__( ' superscript', 'mekhbahadur'), 
        'fa fa-table' => esc_html__( ' table', 'mekhbahadur'), 
        'fa fa-text-height' => esc_html__( ' text-height', 'mekhbahadur'), 
        'fa fa-text-width' => esc_html__( ' text-width', 'mekhbahadur'), 
        'fa fa-th' => esc_html__( ' th', 'mekhbahadur'), 
        'fa fa-th-large' => esc_html__( ' th-large', 'mekhbahadur'), 
        'fa fa-th-list' => esc_html__( ' th-list', 'mekhbahadur'), 
        'fa fa-underline' => esc_html__( ' underline', 'mekhbahadur'), 
        'fa fa-undo' => esc_html__( ' undo', 'mekhbahadur'), 
        'fa fa-unlink' => esc_html__( ' unlink', 'mekhbahadur'), 
        'fa fa-angle-double-down' => esc_html__( ' angle-double-down', 'mekhbahadur'), 
        'fa fa-angle-double-left' => esc_html__( ' angle-double-left', 'mekhbahadur'), 
        'fa fa-angle-double-right' => esc_html__( ' angle-double-right', 'mekhbahadur'), 
        'fa fa-angle-double-up' => esc_html__( ' angle-double-up', 'mekhbahadur'), 
        'fa fa-angle-down' => esc_html__( ' angle-down', 'mekhbahadur'), 
        'fa fa-angle-left' => esc_html__( ' angle-left', 'mekhbahadur'), 
        'fa fa-angle-right' => esc_html__( ' angle-right', 'mekhbahadur'), 
        'fa fa-angle-up' => esc_html__( ' angle-up', 'mekhbahadur'), 
        'fa fa-arrow-circle-down' => esc_html__( ' arrow-circle-down', 'mekhbahadur'), 
        'fa fa-arrow-circle-left' => esc_html__( ' arrow-circle-left', 'mekhbahadur'), 
        'fa fa-arrow-circle-o-down' => esc_html__( ' arrow-circle-o-down', 'mekhbahadur'), 
        'fa fa-arrow-circle-o-left' => esc_html__( ' arrow-circle-o-left', 'mekhbahadur'), 
        'fa fa-arrow-circle-o-right' => esc_html__( ' arrow-circle-o-right', 'mekhbahadur'), 
        'fa fa-arrow-circle-o-up' => esc_html__( ' arrow-circle-o-up', 'mekhbahadur'), 
        'fa fa-arrow-circle-right' => esc_html__( ' arrow-circle-right', 'mekhbahadur'), 
        'fa fa-arrow-circle-up' => esc_html__( ' arrow-circle-up', 'mekhbahadur'), 
        'fa fa-arrow-down' => esc_html__( ' arrow-down', 'mekhbahadur'), 
        'fa fa-arrow-left' => esc_html__( ' arrow-left', 'mekhbahadur'), 
        'fa fa-arrow-right' => esc_html__( ' arrow-right', 'mekhbahadur'), 
        'fa fa-arrow-up' => esc_html__( ' arrow-up', 'mekhbahadur'), 
        'fa fa-arrows' => esc_html__( ' arrows', 'mekhbahadur'), 
        'fa fa-arrows-alt' => esc_html__( ' arrows-alt', 'mekhbahadur'), 
        'fa fa-arrows-h' => esc_html__( ' arrows-h', 'mekhbahadur'), 
        'fa fa-arrows-v' => esc_html__( ' arrows-v', 'mekhbahadur'), 
        'fa fa-caret-down' => esc_html__( ' caret-down', 'mekhbahadur'), 
        'fa fa-caret-left' => esc_html__( ' caret-left', 'mekhbahadur'), 
        'fa fa-caret-right' => esc_html__( ' caret-right', 'mekhbahadur'), 
        'fa fa-caret-square-o-down' => esc_html__( ' caret-square-o-down', 'mekhbahadur'), 
        'fa fa-caret-square-o-left' => esc_html__( ' caret-square-o-left', 'mekhbahadur'), 
        'fa fa-caret-square-o-right' => esc_html__( ' caret-square-o-right', 'mekhbahadur'), 
        'fa fa-caret-square-o-up' => esc_html__( ' caret-square-o-up', 'mekhbahadur'), 
        'fa fa-caret-up' => esc_html__( ' caret-up', 'mekhbahadur'), 
        'fa fa-chevron-circle-down' => esc_html__( ' chevron-circle-down', 'mekhbahadur'), 
        'fa fa-chevron-circle-left' => esc_html__( ' chevron-circle-left', 'mekhbahadur'), 
        'fa fa-chevron-circle-right' => esc_html__( ' chevron-circle-right', 'mekhbahadur'), 
        'fa fa-chevron-circle-up' => esc_html__( ' chevron-circle-up', 'mekhbahadur'), 
        'fa fa-chevron-down' => esc_html__( ' chevron-down', 'mekhbahadur'), 
        'fa fa-chevron-left' => esc_html__( ' chevron-left', 'mekhbahadur'), 
        'fa fa-chevron-right' => esc_html__( ' chevron-right', 'mekhbahadur'), 
        'fa fa-chevron-up' => esc_html__( ' chevron-up', 'mekhbahadur'), 
        'fa fa-exchange' => esc_html__( ' exchange', 'mekhbahadur'), 
        'fa fa-hand-o-down' => esc_html__( ' hand-o-down', 'mekhbahadur'), 
        'fa fa-hand-o-left' => esc_html__( ' hand-o-left', 'mekhbahadur'), 
        'fa fa-hand-o-right' => esc_html__( ' hand-o-right', 'mekhbahadur'), 
        'fa fa-hand-o-up' => esc_html__( ' hand-o-up', 'mekhbahadur'), 
        'fa fa-long-arrow-down' => esc_html__( ' long-arrow-down', 'mekhbahadur'), 
        'fa fa-long-arrow-left' => esc_html__( ' long-arrow-left', 'mekhbahadur'), 
        'fa fa-long-arrow-right' => esc_html__( ' long-arrow-right', 'mekhbahadur'), 
        'fa fa-long-arrow-up' => esc_html__( ' long-arrow-up', 'mekhbahadur'), 
        'fa fa-toggle-down' => esc_html__( ' toggle-down', 'mekhbahadur'), 
        'fa fa-toggle-left' => esc_html__( ' toggle-left', 'mekhbahadur'), 
        'fa fa-toggle-right' => esc_html__( ' toggle-right', 'mekhbahadur'), 
        'fa fa-toggle-up' => esc_html__( ' toggle-up', 'mekhbahadur'), 
        'fa fa-arrows-alt' => esc_html__( ' arrows-alt', 'mekhbahadur'), 
        'fa fa-backward' => esc_html__( ' backward', 'mekhbahadur'), 
        'fa fa-compress' => esc_html__( ' compress', 'mekhbahadur'), 
        'fa fa-eject' => esc_html__( ' eject', 'mekhbahadur'), 
        'fa fa-expand' => esc_html__( ' expand', 'mekhbahadur'), 
        'fa fa-fast-backward' => esc_html__( ' fast-backward', 'mekhbahadur'), 
        'fa fa-fast-forward' => esc_html__( ' fast-forward', 'mekhbahadur'), 
        'fa fa-forward' => esc_html__( ' forward', 'mekhbahadur'), 
        'fa fa-pause' => esc_html__( ' pause', 'mekhbahadur'), 
        'fa fa-play' => esc_html__( ' play', 'mekhbahadur'), 
        'fa fa-play-circle' => esc_html__( ' play-circle', 'mekhbahadur'), 
        'fa fa-play-circle-o' => esc_html__( ' play-circle-o', 'mekhbahadur'), 
        'fa fa-random' => esc_html__( ' random', 'mekhbahadur'), 
        'fa fa-step-backward' => esc_html__( ' step-backward', 'mekhbahadur'), 
        'fa fa-step-forward' => esc_html__( ' step-forward', 'mekhbahadur'), 
        'fa fa-stop' => esc_html__( ' stop', 'mekhbahadur'), 
        'fa fa-youtube-play' => esc_html__( ' youtube-play', 'mekhbahadur'), 
        'fa fa-500px' => esc_html__( ' 500px', 'mekhbahadur'), 
        'fa fa-adn' => esc_html__( ' adn', 'mekhbahadur'), 
        'fa fa-amazon' => esc_html__( ' amazon', 'mekhbahadur'), 
        'fa fa-android' => esc_html__( ' android', 'mekhbahadur'), 
        'fa fa-angellist' => esc_html__( ' angellist', 'mekhbahadur'), 
        'fa fa-apple' => esc_html__( ' apple', 'mekhbahadur'), 
        'fa fa-behance' => esc_html__( ' behance', 'mekhbahadur'), 
        'fa fa-behance-square' => esc_html__( ' behance-square', 'mekhbahadur'), 
        'fa fa-bitbucket' => esc_html__( ' bitbucket', 'mekhbahadur'), 
        'fa fa-bitbucket-square' => esc_html__( ' bitbucket-square', 'mekhbahadur'), 
        'fa fa-bitcoin' => esc_html__( ' bitcoin', 'mekhbahadur'), 
        'fa fa-black-tie' => esc_html__( ' black-tie', 'mekhbahadur'), 
        'fa fa-btc' => esc_html__( ' btc', 'mekhbahadur'), 
        'fa fa-buysellads' => esc_html__( ' buysellads', 'mekhbahadur'), 
        'fa fa-cc-amex' => esc_html__( ' cc-amex', 'mekhbahadur'), 
        'fa fa-cc-diners-club' => esc_html__( ' cc-diners-club', 'mekhbahadur'), 
        'fa fa-cc-discover' => esc_html__( ' cc-discover', 'mekhbahadur'), 
        'fa fa-cc-jcb' => esc_html__( ' cc-jcb', 'mekhbahadur'), 
        'fa fa-cc-mastercard' => esc_html__( ' cc-mastercard', 'mekhbahadur'), 
        'fa fa-cc-paypal' => esc_html__( ' cc-paypal', 'mekhbahadur'), 
        'fa fa-cc-stripe' => esc_html__( ' cc-stripe', 'mekhbahadur'), 
        'fa fa-cc-visa' => esc_html__( ' cc-visa', 'mekhbahadur'), 
        'fa fa-chrome' => esc_html__( ' chrome', 'mekhbahadur'), 
        'fa fa-codepen' => esc_html__( ' codepen', 'mekhbahadur'), 
        'fa fa-connectdevelop' => esc_html__( ' connectdevelop', 'mekhbahadur'), 
        'fa fa-contao' => esc_html__( ' contao', 'mekhbahadur'), 
        'fa fa-css3' => esc_html__( ' css3', 'mekhbahadur'), 
        'fa fa-dashcube' => esc_html__( ' dashcube', 'mekhbahadur'), 
        'fa fa-delicious' => esc_html__( ' delicious', 'mekhbahadur'), 
        'fa fa-deviantart' => esc_html__( ' deviantart', 'mekhbahadur'), 
        'fa fa-digg' => esc_html__( ' digg', 'mekhbahadur'), 
        'fa fa-dribbble' => esc_html__( ' dribbble', 'mekhbahadur'), 
        'fa fa-dropbox' => esc_html__( ' dropbox', 'mekhbahadur'), 
        'fa fa-drupal' => esc_html__( ' drupal', 'mekhbahadur'), 
        'fa fa-empire' => esc_html__( ' empire', 'mekhbahadur'), 
        'fa fa-expeditedssl' => esc_html__( ' expeditedssl', 'mekhbahadur'), 
        'fa fa-facebook' => esc_html__( ' facebook', 'mekhbahadur'), 
        'fa fa-facebook-f' => esc_html__( ' facebook-f', 'mekhbahadur'), 
        'fa fa-facebook-official' => esc_html__( ' facebook-official', 'mekhbahadur'), 
        'fa fa-facebook-square' => esc_html__( ' facebook-square', 'mekhbahadur'), 
        'fa fa-firefox' => esc_html__( ' firefox', 'mekhbahadur'), 
        'fa fa-flickr' => esc_html__( ' flickr', 'mekhbahadur'), 
        'fa fa-fonticons' => esc_html__( ' fonticons', 'mekhbahadur'), 
        'fa fa-forumbee' => esc_html__( ' forumbee', 'mekhbahadur'), 
        'fa fa-foursquare' => esc_html__( ' foursquare', 'mekhbahadur'), 
        'fa fa-ge' => esc_html__( ' ge', 'mekhbahadur'), 
        'fa fa-get-pocket' => esc_html__( ' get-pocket', 'mekhbahadur'), 
        'fa fa-gg' => esc_html__( ' gg', 'mekhbahadur'), 
        'fa fa-gg-circle' => esc_html__( ' gg-circle', 'mekhbahadur'), 
        'fa fa-git' => esc_html__( ' git', 'mekhbahadur'), 
        'fa fa-git-square' => esc_html__( ' git-square', 'mekhbahadur'), 
        'fa fa-github' => esc_html__( ' github', 'mekhbahadur'), 
        'fa fa-github-alt' => esc_html__( ' github-alt', 'mekhbahadur'), 
        'fa fa-github-square' => esc_html__( ' github-square', 'mekhbahadur'), 
        'fa fa-gittip' => esc_html__( ' gittip', 'mekhbahadur'), 
        'fa fa-google' => esc_html__( ' google', 'mekhbahadur'), 
        'fa fa-google-plus' => esc_html__( ' google-plus', 'mekhbahadur'), 
        'fa fa-google-plus-square' => esc_html__( ' google-plus-square', 'mekhbahadur'), 
        'fa fa-google-wallet' => esc_html__( ' google-wallet', 'mekhbahadur'), 
        'fa fa-gratipay' => esc_html__( ' gratipay', 'mekhbahadur'), 
        'fa fa-hacker-news' => esc_html__( ' hacker-news', 'mekhbahadur'), 
        'fa fa-houzz' => esc_html__( ' houzz', 'mekhbahadur'), 
        'fa fa-html5' => esc_html__( ' html5', 'mekhbahadur'), 
        'fa fa-instagram' => esc_html__( ' instagram', 'mekhbahadur'), 
        'fa fa-internet-explorer' => esc_html__( ' internet-explorer', 'mekhbahadur'), 
        'fa fa-ioxhost' => esc_html__( ' ioxhost', 'mekhbahadur'), 
        'fa fa-joomla' => esc_html__( ' joomla', 'mekhbahadur'), 
        'fa fa-jsfiddle' => esc_html__( ' jsfiddle', 'mekhbahadur'), 
        'fa fa-lastfm' => esc_html__( ' lastfm', 'mekhbahadur'), 
        'fa fa-lastfm-square' => esc_html__( ' lastfm-square', 'mekhbahadur'), 
        'fa fa-leanpub' => esc_html__( ' leanpub', 'mekhbahadur'), 
        'fa fa-linkedin' => esc_html__( ' linkedin', 'mekhbahadur'), 
        'fa fa-linkedin-square' => esc_html__( ' linkedin-square', 'mekhbahadur'), 
        'fa fa-linux' => esc_html__( ' linux', 'mekhbahadur'), 
        'fa fa-maxcdn' => esc_html__( ' maxcdn', 'mekhbahadur'), 
        'fa fa-meanpath' => esc_html__( ' meanpath', 'mekhbahadur'), 
        'fa fa-medium' => esc_html__( ' medium', 'mekhbahadur'), 
        'fa fa-odnoklassniki' => esc_html__( ' odnoklassniki', 'mekhbahadur'), 
        'fa fa-odnoklassniki-square' => esc_html__( ' odnoklassniki-square', 'mekhbahadur'), 
        'fa fa-opencart' => esc_html__( ' opencart', 'mekhbahadur'), 
        'fa fa-openid' => esc_html__( ' openid', 'mekhbahadur'), 
        'fa fa-opera' => esc_html__( ' opera', 'mekhbahadur'), 
        'fa fa-optin-monster' => esc_html__( ' optin-monster', 'mekhbahadur'), 
        'fa fa-pagelines' => esc_html__( ' pagelines', 'mekhbahadur'), 
        'fa fa-paypal' => esc_html__( ' paypal', 'mekhbahadur'), 
        'fa fa-pied-piper' => esc_html__( ' pied-piper', 'mekhbahadur'), 
        'fa fa-pied-piper-alt' => esc_html__( ' pied-piper-alt', 'mekhbahadur'), 
        'fa fa-pinterest' => esc_html__( ' pinterest', 'mekhbahadur'), 
        'fa fa-pinterest-p' => esc_html__( ' pinterest-p', 'mekhbahadur'), 
        'fa fa-pinterest-square' => esc_html__( ' pinterest-square', 'mekhbahadur'), 
        'fa fa-qq' => esc_html__( ' qq', 'mekhbahadur'), 
        'fa fa-ra' => esc_html__( ' ra', 'mekhbahadur'), 
        'fa fa-rebel' => esc_html__( ' rebel', 'mekhbahadur'), 
        'fa fa-reddit' => esc_html__( ' reddit', 'mekhbahadur'), 
        'fa fa-reddit-square' => esc_html__( ' reddit-square', 'mekhbahadur'), 
        'fa fa-renren' => esc_html__( ' renren', 'mekhbahadur'), 
        'fa fa-safari' => esc_html__( ' safari', 'mekhbahadur'), 
        'fa fa-sellsy' => esc_html__( ' sellsy', 'mekhbahadur'), 
        'fa fa-share-alt' => esc_html__( ' share-alt', 'mekhbahadur'), 
        'fa fa-share-alt-square' => esc_html__( ' share-alt-square', 'mekhbahadur'), 
        'fa fa-shirtsinbulk' => esc_html__( ' shirtsinbulk', 'mekhbahadur'), 
        'fa fa-simplybuilt' => esc_html__( ' simplybuilt', 'mekhbahadur'), 
        'fa fa-skyatlas' => esc_html__( ' skyatlas', 'mekhbahadur'), 
        'fa fa-skype' => esc_html__( ' skype', 'mekhbahadur'), 
        'fa fa-slack' => esc_html__( ' slack', 'mekhbahadur'), 
        'fa fa-slideshare' => esc_html__( ' slideshare', 'mekhbahadur'), 
        'fa fa-soundcloud' => esc_html__( ' soundcloud', 'mekhbahadur'), 
        'fa fa-spotify' => esc_html__( ' spotify', 'mekhbahadur'), 
        'fa fa-stack-exchange' => esc_html__( ' stack-exchange', 'mekhbahadur'), 
        'fa fa-stack-overflow' => esc_html__( ' stack-overflow', 'mekhbahadur'), 
        'fa fa-steam' => esc_html__( ' steam', 'mekhbahadur'), 
        'fa fa-steam-square' => esc_html__( ' steam-square', 'mekhbahadur'), 
        'fa fa-stumbleupon' => esc_html__( ' stumbleupon', 'mekhbahadur'), 
        'fa fa-stumbleupon-circle' => esc_html__( ' stumbleupon-circle', 'mekhbahadur'), 
        'fa fa-tencent-weibo' => esc_html__( ' tencent-weibo', 'mekhbahadur'), 
        'fa fa-trello' => esc_html__( ' trello', 'mekhbahadur'), 
        'fa fa-tripadvisor' => esc_html__( ' tripadvisor', 'mekhbahadur'), 
        'fa fa-tumblr' => esc_html__( ' tumblr', 'mekhbahadur'), 
        'fa fa-tumblr-square' => esc_html__( ' tumblr-square', 'mekhbahadur'), 
        'fa fa-twitch' => esc_html__( ' twitch', 'mekhbahadur'), 
        'fa fa-twitter' => esc_html__( ' twitter', 'mekhbahadur'), 
        'fa fa-twitter-square' => esc_html__( ' twitter-square', 'mekhbahadur'), 
        'fa fa-viacoin' => esc_html__( ' viacoin', 'mekhbahadur'), 
        'fa fa-vimeo' => esc_html__( ' vimeo', 'mekhbahadur'), 
        'fa fa-vimeo-square' => esc_html__( ' vimeo-square', 'mekhbahadur'), 
        'fa fa-vine' => esc_html__( ' vine', 'mekhbahadur'), 
        'fa fa-vk' => esc_html__( ' vk', 'mekhbahadur'), 
        'fa fa-wechat' => esc_html__( ' wechat', 'mekhbahadur'), 
        'fa fa-weibo' => esc_html__( ' weibo', 'mekhbahadur'), 
        'fa fa-weixin' => esc_html__( ' weixin', 'mekhbahadur'), 
        'fa fa-whatsapp' => esc_html__( ' whatsapp', 'mekhbahadur'), 
        'fa fa-wikipedia-w' => esc_html__( ' wikipedia-w', 'mekhbahadur'), 
        'fa fa-windows' => esc_html__( ' windows', 'mekhbahadur'), 
        'fa fa-wordpress' => esc_html__( ' wordpress', 'mekhbahadur'), 
        'fa fa-xing' => esc_html__( ' xing', 'mekhbahadur'), 
        'fa fa-xing-square' => esc_html__( ' xing-square', 'mekhbahadur'), 
        'fa fa-y-combinator' => esc_html__( ' y-combinator', 'mekhbahadur'), 
        'fa fa-y-combinator-square' => esc_html__( ' y-combinator-square', 'mekhbahadur'), 
        'fa fa-yahoo' => esc_html__( ' yahoo', 'mekhbahadur'), 
        'fa fa-yc' => esc_html__( ' yc', 'mekhbahadur'), 
        'fa fa-yc-square' => esc_html__( ' yc-square', 'mekhbahadur'), 
        'fa fa-yelp' => esc_html__( ' yelp', 'mekhbahadur'), 
        'fa fa-youtube' => esc_html__( ' youtube', 'mekhbahadur'), 
        'fa fa-youtube-play' => esc_html__( ' youtube-play', 'mekhbahadur'), 
        'fa fa-youtube-square' => esc_html__( ' youtube-square', 'mekhbahadur'), 
        'fa fa-ambulance' => esc_html__( ' ambulance', 'mekhbahadur'), 
        'fa fa-h-square' => esc_html__( ' h-square', 'mekhbahadur'), 
        'fa fa-heart' => esc_html__( ' heart', 'mekhbahadur'), 
        'fa fa-heart-o' => esc_html__( ' heart-o', 'mekhbahadur'), 
        'fa fa-heartbeat' => esc_html__( ' heartbeat', 'mekhbahadur'), 
        'fa fa-hospital-o' => esc_html__( ' hospital-o', 'mekhbahadur'), 
        'fa fa-medkit' => esc_html__( ' medkit', 'mekhbahadur'), 
        'fa fa-plus-square' => esc_html__( ' plus-square', 'mekhbahadur'), 
        'fa fa-stethoscope' => esc_html__( ' stethoscope', 'mekhbahadur'), 
        'fa fa-user-md' => esc_html__( ' user-md', 'mekhbahadur'), 
        'fa fa-wheelchair' => esc_html__( ' wheelchair', 'mekhbahadur')
	);
}