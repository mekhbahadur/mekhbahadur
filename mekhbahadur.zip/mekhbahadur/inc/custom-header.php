<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
	<?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package Mekh_Bahadur
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses mekhbahadur_header_style()
 */
function mekhbahadur_custom_header_setup() {
	add_theme_support( 'custom-header', apply_filters( 'mekhbahadur_custom_header_args', array(
		'default-image'          => '',
		'default-text-color'     => '000000',
		'width'                  => 1000,
		'height'                 => 250,
		'flex-height'            => true,
		'wp-head-callback'       => 'mekhbahadur_header_style',
	) ) );
}
add_action( 'after_setup_theme', 'mekhbahadur_custom_header_setup' );

if ( ! function_exists( 'mekhbahadur_header_style' ) ) :
	/**
	 * Styles the header image and text displayed on the blog.
	 *
	 * @see mekhbahadur_custom_header_setup().
	 */
	function mekhbahadur_header_style() {
		$header_text_color = get_header_textcolor();

		/*
		 * If no custom options for text are set, let's bail.
		 * get_header_textcolor() options: Any hex value, 'blank' to hide text. Default: add_theme_support( 'custom-header' ).
		 */
		if ( get_theme_support( 'custom-header', 'default-text-color' ) === $header_text_color ) {
			return;
		}

		// If we get this far, we have custom styles. Let's do this.
		?>
		<style type="text/css">
		<?php
		// Has the text been hidden?
		if ( ! display_header_text() ) :
		?>
			.site-title,
			.site-description {
				position: absolute;
				clip: rect(1px, 1px, 1px, 1px);
			}
		<?php
			// If the user has set a custom color for the text use that.
			else :
		?>
			.site-title a,
			.site-description {
				color: #<?php echo esc_attr( $header_text_color ); ?>;
			}
		<?php endif; ?>
		</style>
		<?php
	}
endif;

function mekhbahadur_add_style() { ?>
	<style>
		.site-header {
			background-color: <?php echo esc_attr( get_theme_mod( 'bgcolor_1' ) );?>;
			padding-top: <?php echo esc_attr( get_theme_mod( 'padding_top_setting_1' ) );?>px;
			padding-bottom: <?php echo esc_attr( get_theme_mod( 'padding_bottom_setting_1' ) );?>px;
		}
		.site-header h1, .site-header h2, .site-header h3 {
			line-height: <?php echo esc_attr( get_theme_mod( 'title_lineheight_1' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'title_fontsize_1' ) ) ;?>px;
		}
		.site-header p {
			line-height: <?php echo esc_attr( get_theme_mod( 'content_lineheight_1' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'content_fontsize_1' ) ) ;?>px;
		}
		.site-content {
			background-color: <?php echo esc_attr( get_theme_mod( 'bgcolor_2' ) );?>;
			padding-top: <?php echo esc_attr( get_theme_mod( 'padding_top_setting_2' ) );?>px;
			padding-bottom: <?php echo esc_attr( get_theme_mod( 'padding_bottom_setting_2' ) );?>px;
		}
		.site-content h1, .site-content h2, .site-content h3 {
			line-height: <?php echo esc_attr( get_theme_mod( 'title_lineheight_2' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'title_fontsize_2' ) ) ;?>px;
		}
		.site-content p {
			line-height: <?php echo esc_attr( get_theme_mod( 'content_lineheight_2' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'content_fontsize_2' ) ) ;?>px;
		}
		.service {
			background-color: <?php echo esc_attr( get_theme_mod( 'bgcolor_4' ) );?>;
			padding-top: <?php echo esc_attr( get_theme_mod( 'padding_top_setting_4' ) );?>px;
			padding-bottom: <?php echo esc_attr( get_theme_mod( 'padding_bottom_setting_4' ) );?>px;
		}
		.service h1, .service h2, .service h3 {
			line-height: <?php echo esc_attr( get_theme_mod( 'title_lineheight_4' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'title_fontsize_3' ) ) ;?>px;
		}
		.service p {
			line-height: <?php echo esc_attr( get_theme_mod( 'content_lineheight_4' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'content_fontsize_3' ) ) ;?>px;
		}
		.site-footer {
			background-color: <?php echo esc_attr( get_theme_mod( 'bgcolor_3' ) );?>;
			padding-top: <?php echo esc_attr( get_theme_mod( 'padding_top_setting_3' ) );?>px;
			padding-bottom: <?php echo esc_attr( get_theme_mod( 'padding_bottom_setting_3' ) );?>px;
		}
		.site-footer h1, .site-footer h2, .site-footer h3 {
			line-height: <?php echo esc_attr( get_theme_mod( 'title_lineheight_3' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'title_fontsize_4' ) ) ;?>px;
		}
		.site-footer p {
			line-height: <?php echo esc_attr( get_theme_mod( 'content_lineheight_3' ) ) ;?>em;
			font-size: <?php echo esc_attr( get_theme_mod( 'content_fontsize_4' ) ) ;?>px;
		}
	</style>
	<?php
}
add_action( 'wp_head', 'mekhbahadur_add_style' );