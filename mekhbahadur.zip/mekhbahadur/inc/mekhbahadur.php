<?php
/**
* @author Mekh Bahadur Layo
* @package MekhBahadur
* @file mekhbahadur.php
*/

function mekhbahadur_banner() { 
	if( get_theme_mod( 'activate_service', false ) == true ):
		?>
		<div class="service">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 col-lg-12">
						<h2 class="text-center">Services</h2><br /><br />
					</div>
				<?php 
					for( $i = 1; $i <= 3; $i++ ) {
						if( $i == 1 ) {
							$service = esc_html( get_theme_mod( 'service_title_1' ) );
							$servicedesc = esc_html( get_theme_mod( 'service_section_1' ) );
						} elseif( $i == 2 ) {
							$service = esc_html( get_theme_mod( 'service_title_2' ) );
							$servicedesc = esc_html( get_theme_mod( 'service_section_2' ) );
						} elseif( $i == 3 ) {
							$service = esc_html( get_theme_mod( 'service_title_3' ) );
							$servicedesc = esc_html( get_theme_mod( 'service_section_3' ) );
						}
						?>
						<div id="service-<?php echo $i ;?>" class="col-sm-4 col-lg-4 text-center wow fadeInLeft animated" data-wow-delay="0.8">
						<span id="icon-position-<?php echo $i ;?>" style="margin-top:-<?php echo get_theme_mod( 'service_icon_position_' . $i );?>px;" class="<?php echo get_theme_mod( 'service_icons_' . $i ) . ' ' . get_theme_mod( 'service_icons_times_' . $i ) ;?>"></span>
						<h3 class="title<?php echo $i ;?> text-center" data-wowo-delay="0.7"><?php echo $service ;?></h3>
						<p id="section<?php echo $i ;?>"><?php echo $servicedesc ;?></p>
						</div>
					<?php
					}
				?>
			</div>
		</div>
	</div>
	<?php
endif;
}

add_action( 'mekhbahadur_activate_banner', 'mekhbahadur_banner' );

function mekhbahadur_social() { 
	if( get_theme_mod( 'activate_social_setting', false ) == true ):
		$socials = array(
			'facebook' => __( 'Facebook', 'mekhbahadur' ),
			'twitter' => __( 'Twitter', 'mekhbahadur' ),
			'google_plus' => __( 'Google-Plus', 'mekhbahadur' ),
			'linkedin' => __( 'Linkedin', 'mekhbahadur' ),
			'youtube' => __( 'YouTube', 'mekhbahadur' ),
			'github' => __( 'Github', 'mekhbahadur' ),
			'stackoverflow' => __( 'Stack-Overflow', 'mekhbahadur' ),
		);
	?>
	<nav id="social" class="bg-success">
		<div class="container">
			<div class="row">
				<div class="col-sm-4">
				<img src="<?php echo get_theme_mod( 'logo_setting' ) ;?>" >
				</div>
				<div class="col-sm-8">
					<ul class="pull-right">
				<?php
				$i = 1;
				$print_social_links = '';
				foreach( $socials as $key => $value ) {
					$link = get_theme_mod( $key, '' );
					if( !empty( $link ) ) {
						if( get_theme_mod( $key, false ) == true ) {
							$target = '_blank';
						} else {
							$target = '_self';
						}
						$print_social_links .= '<li><a href="' . $link . '" target="' . $target . '" title="' . $value . '"><span class="fa fa-' . strtolower( $value ) . ' fa-2x"></span></a></li>';
					}
					$i++;
				} 
				echo $print_social_links;
				?>
				</ul>
				</div>
			</div>
		</div>
	</nav>
	<?php
endif;
}

add_action( 'mekhbahadur_activate_social', 'mekhbahadur_social' );

function mekhbahadur_post_slider() { 
	if( get_theme_mod( 'activate_post_slider', false ) == true ): 
		$wp_query = new WP_Query( 'post_type=post' );
		?>
	<script>
		$(document).ready( function() {
			$( '.post-slider div' ).hide();
			$( '.post-slider div:first-child' ).show();
			setInterval( function() {
				$( '.post-slider div:first-child' )
					.slideUp(1000).next( 'div' )
					.slideDown( 1000 )
					.end()
					.appendTo( '.post-slider' );
			}, <?php echo get_theme_mod( 'post_slider_setting' ) ;?> );
		} );
	</script>
	<div class="post-slider">
		<?php
		if( $wp_query->have_posts() ):
			while( $wp_query->have_posts() ): $wp_query->the_post() ; ?>
			<div style="padding-top: 13em;" class="slider text-center">
				<h1 style="color: #cfc;" class="wow fadeInDown animated" data-wow-delay="0.9"><?php the_title() ;?></h1>
				<?php mekhbahadur_posted_on(); ?>
			</div>
			<?php
			endwhile;
		endif;?>
	</div>
	<?php
endif;
}

add_action( 'do_postslider', 'mekhbahadur_post_slider' );

function mekhbahadur_excerpt_more() {
	return '...';
}

add_filter( 'excerpt_more', 'mekhbahadur_excerpt_more' );

function mekhbahadur_footer_widgets() {
	if( get_theme_mod( 'footer_setting', false ) == '1' ) { ?>
	<div class="col-sm-12 col-lg-12">
		<?php dynamic_sidebar( 'widget-1' ) ;?>
	</div>
	<?php
	} elseif( get_theme_mod( 'footer_setting', false ) == '2' ) { 
		for( $i = 1; $i <= 2; $i++ ) {
		?>
			<div class="col-sm-6 col-lg-6">
				<?php dynamic_sidebar( 'widget-' . $i ) ;?>
			</div>
	<?php }
	} elseif( get_theme_mod( 'footer_setting', false ) == '3' ) { 
		for( $i = 1; $i <= 3; $i++ ) {
		?>
			<div class="col-sm-4 col-lg-4">
				<?php dynamic_sidebar( 'widget-' . $i ) ;?>
			</div>
	<?php }
	} elseif( get_theme_mod( 'footer_setting', false ) == '4' ) { 
		for( $i = 1; $i <= 4; $i++ ) {
		?>
			<div class="col-sm-3 col-lg-3">
				<?php dynamic_sidebar( 'widget-' . $i ) ;?>
			</div>
	<?php }
	}
}

add_action( 'activate_footer_widgets', 'mekhbahadur_footer_widgets' );