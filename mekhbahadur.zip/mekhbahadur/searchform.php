<?php

/**
* @author Mekh Bahadur Layo
* @package MekhBahadur
* @file searchform.php
*/

if( isset( $_GET['s'] ) ) {
	$search_form = $_GET['s'];
}
?>

<form class="form-inline" action="<?php echo esc_url( home_url( '/' ) );?>" method="get">
	<div class="input-group">
		<input type="text" name="s" class="form-control input-lg" placeholder="Search..." value="<?php if( isset( $search_form ) ) echo esc_attr( $search_form );?>">
		<span class="input-group-btn">
			<button type="submit" class="btn btn-warning btn-lg"><span class="fa fa-search"></span></button>
		</span>
	</div>
</form>