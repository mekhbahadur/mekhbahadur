<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mekh_Bahadur
 */

if ( ! is_active_sidebar( 'widget-5' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area">
	<?php dynamic_sidebar( 'widget-5' ); ?>
</aside><!-- #secondary -->
